@echo off
title Painel Fiscal SGI-PDV
chcp 65001 > nul

echo.
echo ===================================
echo   Painel Fiscal SGI-PDV
echo ===================================
echo.

rem Localiza o SGI-PDV.jar
set JAR=
if exist "C:\pdv\SGI-PDV.jar"            set JAR=C:\pdv\SGI-PDV.jar
if "%JAR%"=="" if exist "..\SGI-PDV.jar"       set JAR=..\SGI-PDV.jar
if "%JAR%"=="" if exist "..\..\SGI-PDV.jar"    set JAR=..\..\SGI-PDV.jar
if "%JAR%"=="" if exist "..\..\..\SGI-PDV.jar" set JAR=..\..\..\SGI-PDV.jar

if "%JAR%"=="" (
    echo [ERRO] SGI-PDV.jar nao encontrado!
    echo Certifique-se de que o arquivo esta em C:\pdv\SGI-PDV.jar
    echo.
    pause
    exit /b 1
)

rem Localiza o driver do Derby. O instalador deixa uma copia aqui do lado,
rem entao esta e a primeira opcao e nao depende do layout do PDV.
set DERBY=
if exist "%~dp0derby.jar"                                 set DERBY=%~dp0derby.jar
if "%DERBY%"=="" if exist "C:\pdv\lib\derby.jar"          set DERBY=C:\pdv\lib\derby.jar
if "%DERBY%"=="" if exist "C:\pdv\Portal NFCe\derby.jar"  set DERBY=C:\pdv\Portal NFCe\derby.jar
if "%DERBY%"=="" if exist "..\lib\derby.jar"              set DERBY=..\lib\derby.jar
if "%DERBY%"=="" if exist "..\..\lib\derby.jar"           set DERBY=..\..\lib\derby.jar
if "%DERBY%"=="" if exist "..\Portal NFCe\derby.jar"      set DERBY=..\Portal NFCe\derby.jar
if "%DERBY%"=="" if exist "..\..\Portal NFCe\derby.jar"   set DERBY=..\..\Portal NFCe\derby.jar

rem Ultimo recurso: procura em qualquer subpasta do PDV
if "%DERBY%"=="" (
    for /f "delims=" %%F in ('dir /s /b "C:\pdv\derby.jar" 2^>nul') do call :usar_derby "%%F"
)

if "%DERBY%"=="" (
    echo [ERRO] derby.jar nao encontrado!
    echo Rode o instalar.bat novamente para reinstalar o Painel Fiscal.
    echo.
    pause
    exit /b 1
)

rem Compila automaticamente se o .class nao existir
if not exist "PainelFiscal.class" (
    echo Compilando pela primeira vez...
    javac --release 8 -encoding UTF-8 -cp "%JAR%" PainelFiscal.java
    if %errorlevel% neq 0 (
        echo [ERRO] Falha na compilacao!
        pause
        exit /b 1
    )
    echo [OK] Compilado!
    echo.
)

echo Iniciando servidor na porta 9876...
echo O navegador abrira automaticamente.
echo.
echo Para encerrar: pressione ENTER nesta janela.
echo.

java -cp "%JAR%;%DERBY%;." PainelFiscal

echo.
pause
exit /b 0

rem ── guarda o primeiro derby.jar encontrado e ignora os demais ──
:usar_derby
if "%DERBY%"=="" set DERBY=%~1
goto :eof
