@echo off
title Instalador - Painel Fiscal SGI-PDV
chcp 65001 > nul

echo.
echo ===================================
echo   Instalador - Painel Fiscal SGI-PDV
echo ===================================
echo.

set SCRIPT_DIR=%~dp0

rem 1) Localiza a instalacao do SGI-PDV.
rem    Basta o SGI-PDV.jar: o derby.jar e procurado a parte, mais abaixo.
set PDV_DIR=
if exist "C:\pdv\SGI-PDV.jar" set PDV_DIR=C:\pdv

if "%PDV_DIR%"=="" (
    echo Nao encontrei o SGI-PDV automaticamente em C:\pdv.
    echo.
    set /p PDV_DIR="Informe a pasta onde esta instalado o SGI-PDV (ex: C:\pdv): "
)

if not exist "%PDV_DIR%\SGI-PDV.jar" (
    echo.
    echo [ERRO] Nao encontrei "%PDV_DIR%\SGI-PDV.jar".
    echo Verifique o caminho informado e rode o instalador novamente.
    echo.
    pause
    exit /b 1
)

echo Instalacao do SGI-PDV encontrada em: %PDV_DIR%
echo.

rem 2) Localiza o derby.jar. Procura, em ordem:
rem      a) os locais padrao (lib\ e Portal NFCe\)
rem      b) qualquer subpasta do PDV (instalacoes variam de layout)
rem      c) a copia que acompanha este pacote (ultimo recurso)
set DERBY_SRC=
if exist "%PDV_DIR%\lib\derby.jar"         set DERBY_SRC=%PDV_DIR%\lib\derby.jar
if "%DERBY_SRC%"=="" if exist "%PDV_DIR%\Portal NFCe\derby.jar" set DERBY_SRC=%PDV_DIR%\Portal NFCe\derby.jar

if "%DERBY_SRC%"=="" (
    echo Procurando o derby.jar dentro de "%PDV_DIR%"...
    for /f "delims=" %%F in ('dir /s /b "%PDV_DIR%\derby.jar" 2^>nul') do call :usar_derby "%%F"
)

if "%DERBY_SRC%"=="" if exist "%SCRIPT_DIR%derby.jar" (
    set DERBY_SRC=%SCRIPT_DIR%derby.jar
    echo Nenhum derby.jar no PDV: usando a copia que acompanha o pacote.
)

if "%DERBY_SRC%"=="" (
    echo.
    echo [ERRO] Nao encontrei o derby.jar em lugar nenhum, e o pacote nao trouxe uma copia.
    echo Reinstale o Painel Fiscal a partir do ZIP completo.
    echo.
    pause
    exit /b 1
)

echo Derby encontrado em: %DERBY_SRC%
echo.

rem 3) Copia os arquivos do Painel Fiscal para dentro da instalacao do PDV
set DEST=%PDV_DIR%\painel-fiscal
if not exist "%DEST%" mkdir "%DEST%"

copy /Y "%SCRIPT_DIR%PainelFiscal*.class" "%DEST%\" >nul
copy /Y "%SCRIPT_DIR%index.html"          "%DEST%\" >nul
copy /Y "%SCRIPT_DIR%iniciar.bat"         "%DEST%\" >nul

rem Leva o derby junto: assim o iniciar.bat nao depende do layout do PDV.
copy /Y "%DERBY_SRC%" "%DEST%\derby.jar" >nul

echo Arquivos copiados para: %DEST%
echo.

rem 4) Cria atalho na area de trabalho
set SHORTCUT=%USERPROFILE%\Desktop\Painel Fiscal.lnk
powershell -NoProfile -Command ^
    "$s = (New-Object -COM WScript.Shell).CreateShortcut('%SHORTCUT%');" ^
    "$s.TargetPath = '%DEST%\iniciar.bat';" ^
    "$s.WorkingDirectory = '%DEST%';" ^
    "$s.IconLocation = 'shell32.dll,220';" ^
    "$s.Save()"

echo Atalho criado na area de trabalho: "Painel Fiscal"
echo.
echo ===================================
echo   Instalacao concluida!
echo ===================================
echo.

set /p ABRIR="Abrir o Painel Fiscal agora? (S/N): "
if /i "%ABRIR%"=="S" start "" "%DEST%\iniciar.bat"

pause
exit /b 0

rem ── guarda o primeiro derby.jar encontrado e ignora os demais ──
:usar_derby
if "%DERBY_SRC%"=="" set DERBY_SRC=%~1
goto :eof
