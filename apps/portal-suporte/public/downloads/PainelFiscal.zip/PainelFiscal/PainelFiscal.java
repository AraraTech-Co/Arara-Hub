import com.sun.net.httpserver.*;
import java.awt.Desktop;
import java.io.*;
import java.math.BigDecimal;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.zip.*;
import javax.net.ssl.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.dom.*;
import javax.xml.crypto.dsig.keyinfo.*;
import javax.xml.crypto.dsig.spec.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;

public class PainelFiscal {

    static final int    PORTA   = 9876;
    static final String DIR_PDV = "C:/pdv";

    // Equivalente a InputStream.readAllBytes() (Java 9+), compatível com Java 8.
    static byte[] readAllBytes(InputStream is) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int n;
        while ((n = is.read(chunk)) != -1) buf.write(chunk, 0, n);
        return buf.toByteArray();
    }

    static class CertInfo {
        char[]           senha;
        KeyStore         ks;
        PrivateKey       pk;
        X509Certificate  cert;
    }

    // ─── MAIN ─────────────────────────────────────────────────────────────────
    public static void main(String[] args) throws Exception {
        System.out.println("=== Painel Fiscal SGI-PDV ===");
        System.out.println("Diretorio PDV : " + DIR_PDV);

        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");

        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", PORTA), 20);
        server.createContext("/api/databases",  PainelFiscal::serveDatabases);
        server.createContext("/api/stats",      PainelFiscal::serveStats);
        server.createContext("/api/notas",      PainelFiscal::serveNotas);
        server.createContext("/api/xml/",       PainelFiscal::serveXml);
        server.createContext("/api/download",   PainelFiscal::serveDownload);
        server.createContext("/api/consultar",     PainelFiscal::serveConsultar);
        server.createContext("/api/inutilizar",   PainelFiscal::serveInutilizar);
        server.createContext("/api/retransmitir", PainelFiscal::serveRetransmitir);
        server.createContext("/api/movimento",    PainelFiscal::serveMovimento);
        server.createContext("/api/fechamento",        PainelFiscal::serveFechamento);
        server.createContext("/api/fechamento-popup", PainelFiscal::serveFechamentoPopup);
        server.createContext("/api/fechar-caixa",   PainelFiscal::serveFecharCaixa);
        server.createContext("/api/info-banco",      PainelFiscal::serveInfoBanco);
        server.createContext("/api/sinc-status",    PainelFiscal::serveSincStatus);
        server.createContext("/api/resinc-caixa",   PainelFiscal::serveResincCaixa);
        server.createContext("/api/resinc-nfes",    PainelFiscal::serveResincNFes);
        server.createContext("/api/corrigir-nota",  PainelFiscal::serveCorrigirNota);
        server.createContext("/api/diag",          PainelFiscal::serveDiag);
        server.createContext("/api/diag-query",   PainelFiscal::serveDiagQuery);
        server.createContext("/",                 PainelFiscal::serveHtml);
        server.setExecutor(Executors.newCachedThreadPool());
        server.start();

        String url = "http://localhost:" + PORTA;
        System.out.println("Servidor iniciado: " + url);

        try {
            if (Desktop.isDesktopSupported())
                Desktop.getDesktop().browse(new URI(url));
        } catch (Exception ignored) {}

        // Encerra limpo mesmo sem ENTER: fechar a janela, Ctrl+C ou taskkill.
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            public void run() { encerrar(server); }
        }));

        // Mantém o processo vivo.
        //
        // hasNextLine() bloqueia enquanto houver console interativo e devolve
        // false quando não há stdin — atalho sem console, javaw, saída
        // redirecionada, serviço ou tarefa agendada. O nextLine() direto
        // lançava NoSuchElementException nesses casos e derrubava o servidor
        // logo depois de subir.
        boolean temConsole = false;
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("Pressione ENTER para encerrar...");
            temConsole = sc.hasNextLine();
            if (temConsole) sc.nextLine();
        } catch (Exception ignored) {}

        if (temConsole) {
            encerrar(server);
            return;
        }

        System.out.println("Sem console interativo — o painel segue no ar em " + url);
        System.out.println("Para encerrar: feche esta janela ou finalize o processo java.");
        new CountDownLatch(1).await();   // bloqueia; quem encerra é o shutdown hook
    }

    private static boolean encerrado = false;

    /** Para o servidor e desliga o Derby. Seguro para chamar mais de uma vez. */
    static synchronized void encerrar(HttpServer server) {
        if (encerrado) return;
        encerrado = true;
        try { server.stop(0); } catch (Exception ignored) {}
        try { DriverManager.getConnection("jdbc:derby:;shutdown=true"); } catch (Exception ignored) {}
        System.out.println("Encerrado.");
    }

    // ─── SERVE HTML ───────────────────────────────────────────────────────────
    static void serveHtml(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equals("GET")) { ex.sendResponseHeaders(405, -1); return; }
        String path = ex.getRequestURI().getPath();
        if (!path.equals("/") && !path.equals("/index.html")) { ex.sendResponseHeaders(404, -1); return; }

        byte[] bytes;
        try {
            bytes = Files.readAllBytes(Paths.get("index.html"));
        } catch (Exception e) {
            String msg = "<h2>index.html nao encontrado</h2><p>Coloque o arquivo index.html na mesma pasta que PainelFiscal.class</p>";
            bytes = msg.getBytes(StandardCharsets.UTF_8);
        }
        ex.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(200, bytes.length);
        ex.getResponseBody().write(bytes);
        ex.getResponseBody().close();
    }

    // ─── SERVE DATABASES ──────────────────────────────────────────────────────
    static void serveDatabases(HttpExchange ex) throws IOException {
        addCors(ex);
        List<String> bancos = listarBancos();
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < bancos.size(); i++) {
            if (i > 0) json.append(",");
            String nome = bancos.get(i);
            boolean bloqueado = new File(DIR_PDV + "/" + nome + "/db.lck").exists();
            json.append("{\"nome\":\"").append(nome).append("\",\"bloqueado\":").append(bloqueado).append("}");
        }
        json.append("]");
        respJson(ex, 200, json.toString());
    }

    // ─── SERVE STATS (dashboard) ──────────────────────────────────────────────
    static void serveStats(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204, -1); return; }

        Map<String, String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco = p.getOrDefault("banco", "");
        if (banco.isEmpty()) { respJson(ex, 400, "{\"erro\":\"Banco nao informado\"}"); return; }

        try (Connection conn = conectar(banco)) {
            ResultSet rs = conn.createStatement().executeQuery(
                "SELECT " +
                "  COUNT(*) AS TOTAL, " +
                "  SUM(CASE WHEN TIPO_SITUACAO='AUTORIZADO'          THEN 1 ELSE 0 END) AS AUTORIZADO, " +
                "  SUM(CASE WHEN TIPO_SITUACAO='EMISSAO_CONTINGENCIA' THEN 1 ELSE 0 END) AS CONTINGENCIA, " +
                "  SUM(CASE WHEN TIPO_SITUACAO='INUTILIZADO'          THEN 1 ELSE 0 END) AS INUTILIZADO, " +
                "  SUM(CASE WHEN TIPO_SITUACAO LIKE 'CANCELADO%'      THEN 1 ELSE 0 END) AS CANCELADO, " +
                "  SUM(CASE WHEN TIPO_SITUACAO='REJEITADO'            THEN 1 ELSE 0 END) AS REJEITADO " +
                "FROM NFE.NFE_NOTA_FISCAL_ELETRONICA");
            rs.next();
            long total       = rs.getLong("TOTAL");
            long autorizado  = rs.getLong("AUTORIZADO");
            long contingencia= rs.getLong("CONTINGENCIA");
            long inutilizado = rs.getLong("INUTILIZADO");
            long cancelado   = rs.getLong("CANCELADO");
            long rejeitado   = rs.getLong("REJEITADO");
            rs.close();

            // ── Informações da empresa ─────────────────────────────────────
            String empresa = ""; String cnpj = "";
            String serie = ""; String dataInicial = "";

            // 1) Tenta coluna EMIT_XNOME na tabela de notas
            try {
                ResultSet r2 = conn.createStatement().executeQuery(
                    "SELECT EMIT_XNOME, EMIT_CNPJ FROM NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                    "WHERE EMIT_XNOME IS NOT NULL FETCH FIRST 1 ROWS ONLY");
                if (r2.next()) {
                    String v = r2.getString("EMIT_XNOME");
                    if (v != null && !v.trim().isEmpty()) empresa = esc(v.trim());
                    v = r2.getString("EMIT_CNPJ");
                    if (v != null && !v.trim().isEmpty()) cnpj = esc(v.trim());
                }
                r2.close();
            } catch (Exception ignored) {}

            // 2) Fallback: tabelas de empresa separadas
            if (empresa.isEmpty()) {
                String[][] tabs = {
                    {"NFE.EMPRESA","XNOME","CNPJ"},
                    {"NFE.EMPRESA","NOME","CNPJ"},
                    {"SGI.EMPRESA","XNOME","CNPJ"},
                    {"NFE.CONFIG_EMPRESA","XNOME","CNPJ"}
                };
                for (String[] t : tabs) {
                    try {
                        ResultSet r2 = conn.createStatement().executeQuery(
                            "SELECT " + t[1] + "," + t[2] + " FROM " + t[0] + " FETCH FIRST 1 ROWS ONLY");
                        if (r2.next()) {
                            String v = r2.getString(t[1]);
                            if (v != null && !v.trim().isEmpty()) empresa = esc(v.trim());
                            v = r2.getString(t[2]);
                            if (v != null && !v.trim().isEmpty()) cnpj = esc(v.trim());
                        }
                        r2.close();
                        if (!empresa.isEmpty()) break;
                    } catch (Exception ignored) {}
                }
            }

            // 3) Extrai CNPJ da chave de acesso se ainda não tiver
            if (cnpj.isEmpty()) {
                try {
                    ResultSet r2 = conn.createStatement().executeQuery(
                        "SELECT CHAVE_ACESSO FROM NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                        "WHERE CHAVE_ACESSO IS NOT NULL FETCH FIRST 1 ROWS ONLY");
                    if (r2.next()) {
                        String chave = r2.getString("CHAVE_ACESSO");
                        if (chave != null) {
                            String digits = chave.replaceAll("[^0-9]", "");
                            if (digits.length() >= 44) {
                                String c = digits.substring(6, 20);
                                cnpj = c.substring(0,2)+"."+c.substring(2,5)+"."+
                                       c.substring(5,8)+"/"+c.substring(8,12)+"-"+c.substring(12);
                            }
                        }
                    }
                    r2.close();
                } catch (Exception ignored) {}
            }

            // 4) Série mais usada
            try {
                ResultSet r2 = conn.createStatement().executeQuery(
                    "SELECT IDE_SERIE FROM NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                    "GROUP BY IDE_SERIE ORDER BY COUNT(*) DESC FETCH FIRST 1 ROWS ONLY");
                if (r2.next()) {
                    String v = r2.getString("IDE_SERIE");
                    if (v != null) serie = esc(v.trim());
                }
                r2.close();
            } catch (Exception ignored) {}

            // 5) Data da primeira nota
            try {
                ResultSet r2 = conn.createStatement().executeQuery(
                    "SELECT MIN(IDE_DHEMI) AS DATA_INI FROM NFE.NFE_NOTA_FISCAL_ELETRONICA");
                if (r2.next()) {
                    java.sql.Timestamp ts = r2.getTimestamp("DATA_INI");
                    if (ts != null)
                        dataInicial = new java.text.SimpleDateFormat("dd/MM/yyyy").format(ts);
                }
                r2.close();
            } catch (Exception ignored) {}

            respJson(ex, 200,
                "{\"total\":"        + total        + "," +
                "\"autorizado\":"    + autorizado   + "," +
                "\"contingencia\":"  + contingencia + "," +
                "\"inutilizado\":"   + inutilizado  + "," +
                "\"cancelado\":"     + cancelado    + "," +
                "\"rejeitado\":"     + rejeitado    + "," +
                "\"empresa\":\""     + empresa      + "\"," +
                "\"cnpj\":\""        + cnpj         + "\"," +
                "\"serie\":\""       + serie        + "\"," +
                "\"dataInicial\":\"" + dataInicial  + "\"}");

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(tratarErro(e)) + "\"}");
        }
    }

    // ─── SERVE NOTAS ──────────────────────────────────────────────────────────
    static void serveNotas(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204, -1); return; }

        Map<String, String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco = p.getOrDefault("banco", "");
        if (banco.isEmpty()) { respJson(ex, 400, "{\"erro\":\"Banco nao informado\"}"); return; }

        try (Connection conn = conectar(banco)) {
            StringBuilder sql = new StringBuilder(
                "SELECT n.ID, n.IDE_NNF, n.IDE_SERIE, n.IDE_MOD, " +
                "n.IDE_DHEMI, n.DATA_HORA_AUTORIZACAO, n.TIPO_SITUACAO, " +
                "n.CHAVE_ACESSO, n.VNF, n.DEST_XNOME, n.DEST_CNPJ, " +
                "n.PROTOCOLOAUTORIZACAO, n.EMITIDA_CONTINGENCIA, n.MOTIVOCANCELAMENTO " +
                "FROM NFE.NFE_NOTA_FISCAL_ELETRONICA n WHERE 1=1"
            );
            List<Object> vals = new ArrayList<>();

            String di  = p.getOrDefault("dataInicio", "");
            String df  = p.getOrDefault("dataFim", "");
            String num = p.getOrDefault("numero", "");
            String de  = p.getOrDefault("numDe", "");
            String ate = p.getOrDefault("numAte", "");
            String sit = p.getOrDefault("situacao", "");

            boolean porNumero = !num.isEmpty() || !de.isEmpty() || !ate.isEmpty();
            if (!porNumero) {
                if (!di.isEmpty()) { sql.append(" AND n.IDE_DHEMI >= ?"); vals.add(Timestamp.valueOf(di + " 00:00:00")); }
                if (!df.isEmpty()) { sql.append(" AND n.IDE_DHEMI <= ?"); vals.add(Timestamp.valueOf(df + " 23:59:59")); }
            }
            if (!num.isEmpty()) { sql.append(" AND CAST(n.IDE_NNF AS INTEGER) = ?"); vals.add(Integer.valueOf(num)); }
            else {
                if (!de.isEmpty())  { sql.append(" AND CAST(n.IDE_NNF AS INTEGER) >= ?"); vals.add(Integer.valueOf(de)); }
                if (!ate.isEmpty()) { sql.append(" AND CAST(n.IDE_NNF AS INTEGER) <= ?"); vals.add(Integer.valueOf(ate)); }
            }
            if (!sit.isEmpty()) { sql.append(" AND n.TIPO_SITUACAO = ?"); vals.add(sit); }

            sql.append(" ORDER BY CAST(n.IDE_NNF AS INTEGER) DESC FETCH FIRST 2000 ROWS ONLY");

            PreparedStatement ps = conn.prepareStatement(sql.toString());
            for (int i = 0; i < vals.size(); i++) ps.setObject(i + 1, vals.get(i));

            ResultSet rs = ps.executeQuery();
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            while (rs.next()) {
                if (!first) json.append(",");
                first = false;
                BigDecimal vnf = rs.getBigDecimal("VNF");
                json.append("{")
                    .append("\"id\":\"").append(esc(rs.getString("ID"))).append("\",")
                    .append("\"numero\":\"").append(esc(rs.getString("IDE_NNF"))).append("\",")
                    .append("\"serie\":\"").append(esc(rs.getString("IDE_SERIE"))).append("\",")
                    .append("\"modelo\":\"").append(esc(rs.getString("IDE_MOD"))).append("\",")
                    .append("\"dataEmissao\":\"").append(fmtTs(rs.getTimestamp("IDE_DHEMI"))).append("\",")
                    .append("\"dataAutorizacao\":\"").append(fmtTs(rs.getTimestamp("DATA_HORA_AUTORIZACAO"))).append("\",")
                    .append("\"situacao\":\"").append(esc(rs.getString("TIPO_SITUACAO"))).append("\",")
                    .append("\"chaveAcesso\":\"").append(esc(rs.getString("CHAVE_ACESSO"))).append("\",")
                    .append("\"valor\":\"").append(vnf != null ? vnf.toPlainString() : "0").append("\",")
                    .append("\"destinatario\":\"").append(esc(rs.getString("DEST_XNOME"))).append("\",")
                    .append("\"destCnpj\":\"").append(esc(rs.getString("DEST_CNPJ"))).append("\",")
                    .append("\"protocolo\":\"").append(esc(rs.getString("PROTOCOLOAUTORIZACAO"))).append("\",")
                    .append("\"contingencia\":\"").append(rs.getBoolean("EMITIDA_CONTINGENCIA") ? "S" : "N").append("\",")
                    .append("\"motivoCancelamento\":\"").append(esc(rs.getString("MOTIVOCANCELAMENTO"))).append("\"")
                    .append("}");
            }
            json.append("]");
            respJson(ex, 200, json.toString());

        } catch (Exception e) {
            String msg = tratarErro(e);
            respJson(ex, 500, "{\"erro\":\"" + esc(msg) + "\"}");
        }
    }

    // ─── SERVE XML ────────────────────────────────────────────────────────────
    static void serveXml(HttpExchange ex) throws IOException {
        addCors(ex);
        Map<String, String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco = p.getOrDefault("banco", "");
        String path  = ex.getRequestURI().getPath();
        String id    = path.substring(path.lastIndexOf('/') + 1);

        if (banco.isEmpty() || id.isEmpty()) { respText(ex, 400, "Parametros invalidos"); return; }

        try (Connection conn = conectar(banco)) {
            byte[] xml = xmlDistribuicao(conn, id, "AUTORIZACAO");
            if (xml == null) xml = xmlAssinado(conn, id);
            if (xml == null) { respText(ex, 404, "XML nao encontrado para esta nota"); return; }

            String numero   = numeroNota(conn, id);
            String filename = "NFCe_" + numero + ".xml";

            ex.getResponseHeaders().set("Content-Type", "application/xml; charset=utf-8");
            ex.getResponseHeaders().set("Content-Disposition", "attachment; filename=\"" + filename + "\"");
            ex.sendResponseHeaders(200, xml.length);
            ex.getResponseBody().write(xml);
            ex.getResponseBody().close();
        } catch (Exception e) {
            respText(ex, 500, "Erro: " + e.getMessage());
        }
    }

    // ─── SERVE DOWNLOAD ZIP ───────────────────────────────────────────────────
    static void serveDownload(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204, -1); return; }

        String body  = new String(readAllBytes(ex.getRequestBody()), StandardCharsets.UTF_8);
        String banco = extraiJson(body, "banco");
        List<String> ids = extraiArray(body, "ids");

        if (banco.isEmpty() || ids.isEmpty()) { respText(ex, 400, "Dados invalidos"); return; }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int incluidas = 0;

        try (Connection conn = conectar(banco);
             ZipOutputStream zip = new ZipOutputStream(baos)) {
            zip.setLevel(6);
            for (String id : ids) {
                byte[] xml = xmlDistribuicao(conn, id, "AUTORIZACAO");
                if (xml == null) xml = xmlAssinado(conn, id);
                if (xml == null) continue;
                String numero = numeroNota(conn, id);
                zip.putNextEntry(new ZipEntry("NFCe_" + numero + ".xml"));
                zip.write(xml);
                zip.closeEntry();
                incluidas++;
            }
        } catch (Exception e) {
            respText(ex, 500, "Erro ao gerar ZIP: " + e.getMessage());
            return;
        }

        if (incluidas == 0) { respText(ex, 404, "Nenhum XML encontrado para as notas selecionadas"); return; }

        byte[] zipBytes = baos.toByteArray();
        ex.getResponseHeaders().set("Content-Type", "application/zip");
        ex.getResponseHeaders().set("Content-Disposition", "attachment; filename=\"notas_fiscais.zip\"");
        ex.sendResponseHeaders(200, zipBytes.length);
        ex.getResponseBody().write(zipBytes);
        ex.getResponseBody().close();
    }

    // ─── CONSULTAR SEFAZ ──────────────────────────────────────────────────────
    static void serveConsultar(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204, -1); return; }

        Map<String, String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco = p.getOrDefault("banco", "");
        String id    = p.getOrDefault("id", "");
        if (banco.isEmpty() || id.isEmpty()) {
            respJson(ex, 400, "{\"erro\":\"Parametros invalidos\"}"); return;
        }

        try (Connection conn = conectar(banco)) {
            // Carregar dados da nota
            PreparedStatement ps = conn.prepareStatement(
                "SELECT CHAVE_ACESSO, EMIT_ENDERUF, IDE_NNF, IDE_TPAMB " +
                "FROM NFE.NFE_NOTA_FISCAL_ELETRONICA WHERE ID=?");
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) { respJson(ex, 404, "{\"erro\":\"Nota nao encontrada\"}"); return; }
            String chave  = rs.getString("CHAVE_ACESSO");
            String uf     = rs.getString("EMIT_ENDERUF");
            String tpAmb  = rs.getString("IDE_TPAMB");
            rs.close(); ps.close();

            String wsUrl = urlWebservice(conn, uf, "CONSULTA_PROTOCOLO");
            if (wsUrl == null) {
                respJson(ex, 500, "{\"erro\":\"URL do webservice nao encontrada para UF=" + uf + "\"}"); return;
            }

            CertInfo ci = carregarCertInfo(conn);
            SSLContext sslCtx = criarSSLContext(ci);

            String cUF = chave.substring(0, 2);
            String soap =
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<soap12:Envelope" +
                " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" +
                " xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"" +
                " xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">" +
                "<soap12:Header>" +
                "<nfeCabecMsg xmlns=\"http://www.portalfiscal.inf.br/nfe/wsdl/NFeConsultaProtocolo4\">" +
                "<cUF>" + cUF + "</cUF><versaoDados>4.00</versaoDados>" +
                "</nfeCabecMsg></soap12:Header>" +
                "<soap12:Body>" +
                "<nfeDadosMsg xmlns=\"http://www.portalfiscal.inf.br/nfe/wsdl/NFeConsultaProtocolo4\">" +
                "<consSitNFe xmlns=\"http://www.portalfiscal.inf.br/nfe\" versao=\"4.00\">" +
                "<tpAmb>" + tpAmb + "</tpAmb>" +
                "<xServ>CONSULTAR</xServ>" +
                "<chNFe>" + chave + "</chNFe>" +
                "</consSitNFe></nfeDadosMsg></soap12:Body></soap12:Envelope>";

            String action = "http://www.portalfiscal.inf.br/nfe/wsdl/NFeConsultaProtocolo4/nfeConsultaNF";
            String resp   = chamarSefaz(sslCtx, wsUrl, action, soap);

            String cStat    = extrairTag(resp, "cStat");
            String xMotivo  = extrairTag(resp, "xMotivo");
            String nProt    = extrairTag(resp, "nProt");
            String dhRecbto = extrairTag(resp, "dhRecbto");
            boolean autorizado = "100".equals(cStat) || "150".equals(cStat);

            // Se autorizado no SEFAZ mas pendente no banco: atualiza automaticamente
            if (autorizado && !nProt.isEmpty()) {
                try (PreparedStatement upd = conn.prepareStatement(
                        "UPDATE NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                        "SET TIPO_SITUACAO='AUTORIZADO', PROTOCOLOAUTORIZACAO=?, " +
                        "DATA_HORA_AUTORIZACAO=CURRENT_TIMESTAMP " +
                        "WHERE ID=? AND TIPO_SITUACAO='EMISSAO_CONTINGENCIA'")) {
                    upd.setString(1, nProt);
                    upd.setString(2, id);
                    upd.executeUpdate();
                }
            }

            respJson(ex, 200,
                "{\"cStat\":\"" + esc(cStat) + "\"," +
                "\"xMotivo\":\"" + esc(xMotivo) + "\"," +
                "\"nProt\":\"" + esc(nProt) + "\"," +
                "\"dhRecbto\":\"" + esc(dhRecbto) + "\"," +
                "\"autorizado\":" + autorizado + "}");

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage() != null ? e.getMessage() : e.toString()) + "\"}");
        }
    }

    // ─── INUTILIZAR ───────────────────────────────────────────────────────────
    static void serveInutilizar(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204, -1); return; }
        if (!"POST".equals(ex.getRequestMethod()))   { ex.sendResponseHeaders(405, -1); return; }

        String body  = new String(readAllBytes(ex.getRequestBody()), StandardCharsets.UTF_8);
        String banco = extraiJson(body, "banco");
        String id    = extraiJson(body, "id");
        String just  = extraiJson(body, "justificativa");
        if (banco.isEmpty() || id.isEmpty()) {
            respJson(ex, 400, "{\"erro\":\"Parametros invalidos\"}"); return;
        }
        if (just.isEmpty()) just = "Nota emitida em contingencia offline, sem possibilidade de retransmissao ao SEFAZ";

        try (Connection conn = conectar(banco)) {
            // Dados da nota
            PreparedStatement ps = conn.prepareStatement(
                "SELECT IDE_NNF, IDE_SERIE, IDE_MOD, IDE_CUF, IDE_TPAMB, " +
                "EMIT_CNPJ, EMIT_ENDERUF, IDE_DHEMI " +
                "FROM NFE.NFE_NOTA_FISCAL_ELETRONICA WHERE ID=?");
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) { respJson(ex, 404, "{\"erro\":\"Nota nao encontrada\"}"); return; }

            String nnf   = rs.getString("IDE_NNF");
            String serie = rs.getString("IDE_SERIE");
            String mod   = rs.getString("IDE_MOD");
            String cuf   = rs.getString("IDE_CUF");
            String tpAmb = rs.getString("IDE_TPAMB");
            String cnpj  = rs.getString("EMIT_CNPJ");
            String uf    = rs.getString("EMIT_ENDERUF");
            java.sql.Timestamp dhEmi = rs.getTimestamp("IDE_DHEMI");
            rs.close(); ps.close();

            // Ano e mês da nota
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(dhEmi.getTime());
            String ano = String.format("%02d", cal.get(Calendar.YEAR) % 100);
            String mes = String.format("%02d", cal.get(Calendar.MONTH) + 1);

            // Id do infInut: ID{cUF}{AAMM}{CNPJ}{mod}{serie}{nNFIni}{nNFFin}
            String seriePad = String.format("%03d", Integer.parseInt(serie.trim()));
            String nnfPad   = String.format("%09d", Integer.parseInt(nnf.trim()));
            String inutId   = "ID" + cuf + ano + mes + cnpj + mod + seriePad + nnfPad + nnfPad;

            // XML inutNFe sem assinatura
            String inutXml =
                "<inutNFe xmlns=\"http://www.portalfiscal.inf.br/nfe\" versao=\"4.00\">" +
                "<infInut Id=\"" + inutId + "\">" +
                "<tpAmb>" + tpAmb + "</tpAmb>" +
                "<xServ>INUTILIZAR</xServ>" +
                "<cUF>" + cuf + "</cUF>" +
                "<ano>" + ano + "</ano>" +
                "<CNPJ>" + cnpj + "</CNPJ>" +
                "<mod>" + mod + "</mod>" +
                "<serie>" + serie.trim() + "</serie>" +
                "<nNFIni>" + nnf.trim() + "</nNFIni>" +
                "<nNFFin>" + nnf.trim() + "</nNFFin>" +
                "<xJust>" + xmlEsc(just) + "</xJust>" +
                "</infInut>" +
                "</inutNFe>";

            // Assinar XML
            CertInfo ci = carregarCertInfo(conn);
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            Document doc = dbf.newDocumentBuilder()
                .parse(new ByteArrayInputStream(inutXml.getBytes(StandardCharsets.UTF_8)));
            assinarDocumento(doc, inutId, ci.pk, ci.cert);
            String inutAssinado = docToString(doc);

            // Envelope SOAP
            String wsdlNs = "http://www.portalfiscal.inf.br/nfe/wsdl/NFeInutilizacao4";
            String soap =
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<soap12:Envelope" +
                " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" +
                " xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"" +
                " xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">" +
                "<soap12:Header>" +
                "<nfeCabecMsg xmlns=\"" + wsdlNs + "\">" +
                "<cUF>" + cuf + "</cUF><versaoDados>4.00</versaoDados>" +
                "</nfeCabecMsg></soap12:Header>" +
                "<soap12:Body>" +
                "<nfeDadosMsg xmlns=\"" + wsdlNs + "\">" +
                inutAssinado +
                "</nfeDadosMsg></soap12:Body></soap12:Envelope>";

            String wsUrl = urlWebservice(conn, uf, "INUTILIZACAO");
            if (wsUrl == null) throw new Exception("URL de inutilizacao nao encontrada para UF=" + uf);

            SSLContext sslCtx = criarSSLContext(ci);
            String action = "http://www.portalfiscal.inf.br/nfe/wsdl/NFeInutilizacao4/nfeInutilizacaoNF";
            String resp   = chamarSefaz(sslCtx, wsUrl, action, soap);

            String cStat    = extrairTag(resp, "cStat");
            String xMotivo  = extrairTag(resp, "xMotivo");
            String nProt    = extrairTag(resp, "nProt");
            String dhRecbto = extrairTag(resp, "dhRecbto");
            boolean ok = "102".equals(cStat);

            // 102 = Inutilizacao de numero homologada
            if (ok) {
                try (PreparedStatement upd = conn.prepareStatement(
                        "UPDATE NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                        "SET TIPO_SITUACAO='INUTILIZADO', PROTOCOLOAUTORIZACAO=?, " +
                        "DATAATUALIZACAO=CURRENT_TIMESTAMP WHERE ID=?")) {
                    upd.setString(1, nProt.isEmpty() ? null : nProt);
                    upd.setString(2, id);
                    upd.executeUpdate();
                }
            }

            respJson(ex, 200,
                "{\"cStat\":\"" + esc(cStat) + "\"," +
                "\"xMotivo\":\"" + esc(xMotivo) + "\"," +
                "\"nProt\":\"" + esc(nProt) + "\"," +
                "\"dhRecbto\":\"" + esc(dhRecbto) + "\"," +
                "\"inutilizado\":" + ok + "}");

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage() != null ? e.getMessage() : e.toString()) + "\"}");
        }
    }

    // ─── RETRANSMITIR ─────────────────────────────────────────────────────────
    static void serveRetransmitir(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204, -1); return; }
        if (!"POST".equals(ex.getRequestMethod()))   { ex.sendResponseHeaders(405, -1); return; }

        String body  = new String(readAllBytes(ex.getRequestBody()), StandardCharsets.UTF_8);
        String banco = extraiJson(body, "banco");
        String id    = extraiJson(body, "id");
        if (banco.isEmpty() || id.isEmpty()) {
            respJson(ex, 400, "{\"erro\":\"Parametros invalidos\"}"); return;
        }

        try (Connection conn = conectar(banco)) {
            // Dados da nota
            PreparedStatement ps = conn.prepareStatement(
                "SELECT IDE_NNF, IDE_MOD, IDE_CUF, IDE_TPAMB, CHAVE_ACESSO, " +
                "EMIT_ENDERUF, NUMERO_TENTATIVAS " +
                "FROM NFE.NFE_NOTA_FISCAL_ELETRONICA WHERE ID=?");
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) { respJson(ex, 404, "{\"erro\":\"Nota nao encontrada\"}"); return; }
            String nnf          = rs.getString("IDE_NNF");
            String mod          = rs.getString("IDE_MOD");
            String cuf          = rs.getString("IDE_CUF");
            String tpAmb        = rs.getString("IDE_TPAMB");
            String chave        = rs.getString("CHAVE_ACESSO");
            String uf           = rs.getString("EMIT_ENDERUF");
            int    tentativas   = rs.getInt("NUMERO_TENTATIVAS");
            rs.close(); ps.close();

            // XML assinado original (BLOB)
            byte[] assinadoBytes = xmlAssinado(conn, id);
            if (assinadoBytes == null)
                throw new Exception("XML assinado nao encontrado para esta nota (ID=" + id + ")");

            // Strip XML declaration se presente
            String nfeXml = new String(assinadoBytes, StandardCharsets.UTF_8).trim();
            if (nfeXml.startsWith("<?xml")) nfeXml = nfeXml.substring(nfeXml.indexOf("?>") + 2).trim();

            // ID do lote: timestamp simples
            String idLote = String.valueOf(System.currentTimeMillis()).substring(0, 13);

            // 1=sincrono (NFCe), 0=assincrono (NFe mod 55)
            String indSinc = "65".equals(mod) ? "1" : "0";

            String wsdlNs = "http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4";
            String enviNFe =
                "<enviNFe xmlns=\"http://www.portalfiscal.inf.br/nfe\" versao=\"4.00\">" +
                "<idLote>" + idLote + "</idLote>" +
                "<indSinc>" + indSinc + "</indSinc>" +
                nfeXml +
                "</enviNFe>";

            String soap =
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<soap12:Envelope" +
                " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" +
                " xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"" +
                " xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">" +
                "<soap12:Header>" +
                "<nfeCabecMsg xmlns=\"" + wsdlNs + "\">" +
                "<cUF>" + cuf + "</cUF><versaoDados>4.00</versaoDados>" +
                "</nfeCabecMsg></soap12:Header>" +
                "<soap12:Body>" +
                "<nfeDadosMsg xmlns=\"" + wsdlNs + "\">" +
                enviNFe +
                "</nfeDadosMsg></soap12:Body></soap12:Envelope>";

            String wsUrl = urlWebservice(conn, uf, "AUTORIZACAO");
            if (wsUrl == null) throw new Exception("URL de autorizacao nao encontrada para UF=" + uf);

            CertInfo ci     = carregarCertInfo(conn);
            SSLContext ctx  = criarSSLContext(ci);
            String action   = "http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4/nfeAutorizacaoLote";
            String resp     = chamarSefaz(ctx, wsUrl, action, soap);

            // Verificar cStat em dois niveis: retEnviNFe (lote) e protNFe/infProt (nota)
            String cStatLote = extrairTag(resp, "cStat");
            String xMotivoLote = extrairTag(resp, "xMotivo");

            // Extrair protNFe completo para montar o procNFe
            String protNFeXml = extrairTagFull(resp, "protNFe");
            String cStat      = protNFeXml.isEmpty() ? cStatLote : extrairTag(protNFeXml, "cStat");
            String xMotivo    = protNFeXml.isEmpty() ? xMotivoLote : extrairTag(protNFeXml, "xMotivo");
            String nProt      = extrairTag(protNFeXml, "nProt");
            String dhRecbto   = extrairTag(protNFeXml, "dhRecbto");
            if (dhRecbto.isEmpty()) dhRecbto = extrairTag(resp, "dhRecbto");

            boolean autorizado = "100".equals(cStat) || "150".equals(cStat);

            // Incrementar tentativas independente do resultado
            try (PreparedStatement upd = conn.prepareStatement(
                    "UPDATE NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                    "SET NUMERO_TENTATIVAS=?, DATAATUALIZACAO=CURRENT_TIMESTAMP WHERE ID=?")) {
                upd.setInt(1, tentativas + 1);
                upd.setString(2, id);
                upd.executeUpdate();
            }

            if (autorizado) {
                // Montar procNFe (NFe autorizada + protocolo)
                String procNFe = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                    "<nfeProc xmlns=\"http://www.portalfiscal.inf.br/nfe\" versao=\"4.00\">" +
                    nfeXml + protNFeXml + "</nfeProc>";
                byte[] procBytes = procNFe.getBytes(StandardCharsets.UTF_8);

                // Salvar em NFE_DISTRIBUICAO_XML
                String distId = java.util.UUID.randomUUID().toString();
                try (PreparedStatement ins = conn.prepareStatement(
                        "INSERT INTO NFE.NFE_DISTRIBUICAO_XML " +
                        "(ID, CHAVE_ACESSO, DATAATUALIZACAO, DHRECEBTO, TIPO_DISTRIBUICAO, " +
                        "NPROT, NSEQEVENTO, SINC, TPEVENTO, XML_ARQUIVO, NOTA_FISCAL_ELETRONICA_ID) " +
                        "VALUES (?,?,CURRENT_TIMESTAMP,?,'AUTORIZACAO',?,null,false,null,?,?)")) {
                    ins.setString(1, distId);
                    ins.setString(2, chave);
                    ins.setString(3, dhRecbto);
                    ins.setString(4, nProt);
                    ins.setBytes(5, procBytes);
                    ins.setString(6, id);
                    ins.executeUpdate();
                }

                // Atualizar status da nota
                try (PreparedStatement upd = conn.prepareStatement(
                        "UPDATE NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                        "SET TIPO_SITUACAO='AUTORIZADO', PROTOCOLOAUTORIZACAO=?, " +
                        "DATA_HORA_AUTORIZACAO=CURRENT_TIMESTAMP WHERE ID=?")) {
                    upd.setString(1, nProt);
                    upd.setString(2, id);
                    upd.executeUpdate();
                }
            }

            respJson(ex, 200,
                "{\"cStat\":\"" + esc(cStat) + "\"," +
                "\"xMotivo\":\"" + esc(xMotivo) + "\"," +
                "\"cStatLote\":\"" + esc(cStatLote) + "\"," +
                "\"xMotivoLote\":\"" + esc(xMotivoLote) + "\"," +
                "\"nProt\":\"" + esc(nProt) + "\"," +
                "\"dhRecbto\":\"" + esc(dhRecbto) + "\"," +
                "\"autorizado\":" + autorizado + "," +
                "\"tentativas\":" + (tentativas + 1) + "}");

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage() != null ? e.getMessage() : e.toString()) + "\"}");
        }
    }

    // ─── HELPERS SEFAZ ────────────────────────────────────────────────────────

    static CertInfo carregarCertInfo(Connection conn) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT CERTIFICADO_DIGITAL_ARQUIVO, CERTIFICADO_DIGITAL_SENHA " +
                "FROM NFE.CONFIGURACAO_CERTIFICADO FETCH FIRST 1 ROWS ONLY")) {
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) throw new Exception("Certificado digital nao encontrado no banco");
            byte[] certBytes = rs.getBytes(1);
            byte[] senhaBlob = rs.getBytes(2);

            // Formato: UTF-8 bytes de Base64(SHA256_hex[64] + senha_plaintext)
            String b64   = new String(senhaBlob, StandardCharsets.UTF_8);
            String inner = new String(java.util.Base64.getDecoder().decode(b64), StandardCharsets.UTF_8);
            char[] senha = (inner.length() > 64 ? inner.substring(64) : inner).toCharArray();

            KeyStore ks = KeyStore.getInstance("PKCS12");
            ks.load(new ByteArrayInputStream(certBytes), senha);
            String alias = ks.aliases().nextElement();

            CertInfo ci = new CertInfo();
            ci.senha = senha;
            ci.ks    = ks;
            ci.pk    = (PrivateKey) ks.getKey(alias, senha);
            ci.cert  = (X509Certificate) ks.getCertificate(alias);
            return ci;
        }
    }

    static SSLContext criarSSLContext(CertInfo ci) throws Exception {
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ci.ks, ci.senha);

        // Os certificados ICP-Brasil nao estao no truststore padrao do JDK — usa trust-all
        TrustManager[] trustAll = { new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] c, String a) {}
            public void checkServerTrusted(X509Certificate[] c, String a) {}
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        }};

        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(kmf.getKeyManagers(), trustAll, new SecureRandom());
        return ctx;
    }

    static String chamarSefaz(SSLContext sslCtx, String urlStr, String action, String soapEnvelope)
            throws Exception {
        URL url = new URL(urlStr);
        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
        conn.setSSLSocketFactory(sslCtx.getSocketFactory());
        conn.setHostnameVerifier((h, s) -> true);
        conn.setConnectTimeout(30_000);
        conn.setReadTimeout(60_000);
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type",
            "application/soap+xml; charset=utf-8; action=\"" + action + "\"");

        byte[] bodyBytes = soapEnvelope.getBytes(StandardCharsets.UTF_8);
        conn.setRequestProperty("Content-Length", String.valueOf(bodyBytes.length));
        try (OutputStream os = conn.getOutputStream()) { os.write(bodyBytes); }

        int code = conn.getResponseCode();
        InputStream is = code < 400 ? conn.getInputStream() : conn.getErrorStream();
        if (is == null) throw new Exception("SEFAZ retornou HTTP " + code + " sem corpo de resposta");
        return new String(readAllBytes(is), StandardCharsets.UTF_8);
    }

    static String urlWebservice(Connection conn, String uf, String servico) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT URL FROM NFE.NFE_WEBSERVICE " +
                "WHERE ESTADO_SIGLA=? AND TIPO_SERVICO_NFE=? AND ATIVO=1 " +
                "AND TIPO_EMISSAO='NORMAL' FETCH FIRST 1 ROWS ONLY")) {
            ps.setString(1, uf);
            ps.setString(2, servico);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? rs.getString(1) : null;
        }
    }

    static String extrairTag(String xml, String tag) {
        String open  = "<" + tag + ">";
        String close = "</" + tag + ">";
        int i = xml.indexOf(open);
        if (i < 0) return "";
        i += open.length();
        int j = xml.indexOf(close, i);
        return j < 0 ? "" : xml.substring(i, j).trim();
    }

    // Extrai o elemento completo <tag ...>...</tag> (com atributos e namespace)
    static String extrairTagFull(String xml, String tag) {
        int i = xml.indexOf("<" + tag);
        if (i < 0) return "";
        String close = "</" + tag + ">";
        int j = xml.indexOf(close, i);
        return j < 0 ? "" : xml.substring(i, j + close.length());
    }

    static void assinarDocumento(Document doc, String refId, PrivateKey pk, X509Certificate cert)
            throws Exception {
        XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

        List<Transform> transforms = Arrays.asList(
            fac.newTransform(Transform.ENVELOPED, (TransformParameterSpec) null),
            fac.newTransform(CanonicalizationMethod.INCLUSIVE, (TransformParameterSpec) null)
        );
        Reference ref = fac.newReference(
            "#" + refId,
            fac.newDigestMethod(DigestMethod.SHA1, null),
            transforms, null, null
        );
        SignedInfo si = fac.newSignedInfo(
            fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE, (C14NMethodParameterSpec) null),
            fac.newSignatureMethod(SignatureMethod.RSA_SHA1, null),
            Collections.singletonList(ref)
        );
        KeyInfoFactory kif = fac.getKeyInfoFactory();
        KeyInfo ki = kif.newKeyInfo(Collections.singletonList(
            kif.newX509Data(Collections.singletonList(cert))
        ));
        XMLSignature sig = fac.newXMLSignature(si, ki);
        DOMSignContext dsc = new DOMSignContext(pk, doc.getDocumentElement());
        sig.sign(dsc);
    }

    static String docToString(Document doc) throws Exception {
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        StringWriter sw = new StringWriter();
        t.transform(new DOMSource(doc), new StreamResult(sw));
        return sw.toString();
    }

    // ─── MOVIMENTO FINANCEIRO ─────────────────────────────────────────────────
    static void serveMovimento(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204, -1); return; }

        Map<String, String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco    = p.getOrDefault("banco", "");
        String situacao = p.getOrDefault("situacao", "");   // "ABERTO" | "FECHADO" | ""
        String tipoData = p.getOrDefault("tipoData", "ABERTURA"); // "ABERTURA" | "FECHAMENTO"
        String dataIni  = p.getOrDefault("dataIni", "");
        String dataFim  = p.getOrDefault("dataFim", "");

        if (banco.isEmpty()) { respJson(ex, 400, "{\"erro\":\"Banco nao informado\"}"); return; }

        try (Connection conn = conectar(banco)) {

            String exprSuperTroco = colExists(conn, "MOVIMENTO", "FIN_MOVIMENTO_ITEM", "VALOR_SUPERTROCO")
                ? "SUM(mi.VALOR_SUPERTROCO)" : "0";

            // ── Coluna de data usada no filtro ───────────────────────────────
            String colData = "FECHAMENTO".equalsIgnoreCase(tipoData)
                ? "c.DATA_FECHAMENTO" : "c.DATA_ABERTURA";

            // ── Construir WHERE ──────────────────────────────────────────────
            StringBuilder where = new StringBuilder(" WHERE 1=1");
            List<Object> vals = new ArrayList<>();

            if (!dataIni.isEmpty()) {
                where.append(" AND ").append(colData).append(" >= ?");
                vals.add(Timestamp.valueOf(dataIni + " 00:00:00"));
            }
            if (!dataFim.isEmpty()) {
                where.append(" AND ").append(colData).append(" <= ?");
                vals.add(Timestamp.valueOf(dataFim + " 23:59:59"));
            }
            // Situação derivada de DATA_FECHAMENTO IS NULL / IS NOT NULL
            if ("ABERTO".equalsIgnoreCase(situacao))
                where.append(" AND c.DATA_FECHAMENTO IS NULL");
            else if ("FECHADO".equalsIgnoreCase(situacao))
                where.append(" AND c.DATA_FECHAMENTO IS NOT NULL");

            // ── Query principal com JOINs nos movimentos ─────────────────────
            // Totais financeiros por caixa calculados via FIN_MOVIMENTO + FIN_MOVIMENTO_ITEM
            // DIFERENCA = saldo_conferencia - total_venda_sistema - valor_inicial
            // (exclui o fundo de troco para mostrar a diferença real de caixa)
            String sql =
                "SELECT " +
                "  c.SEQUENCEGENERATOR_SEQUENCIA                              AS CAIXA, " +
                "  c.DATA_ABERTURA, " +
                "  c.REPRESENTANTE_ABERTURA_NOME                              AS USUARIO_ABERTURA, " +
                "  c.DATA_FECHAMENTO, " +
                "  CASE WHEN c.DATA_FECHAMENTO IS NULL THEN 'ABERTO' ELSE 'FECHADO' END AS SITUACAO, " +
                "  COALESCE(v.TOTAL_VENDA,         0)                        AS TOTAL_VENDA, " +
                "  COALESCE(v.TOTAL_SUPER_TROCO,   0)                        AS TOTAL_SUPER_TROCO, " +
                "  COALESCE(sg.TOTAL_SANGRIA,       0)                        AS TOTAL_SANGRIA, " +
                "  (COALESCE(c.VALOR_DINHEIRO_CONFERENCIA,       0) + " +
                "   COALESCE(c.VALOR_CARTAOCREDITO_CONFERENCIA,  0) + " +
                "   COALESCE(c.VALOR_CARTAODEBITO_CONFERENCIA,   0) + " +
                "   COALESCE(c.VALOR_PIX_CONFERENCIA,            0) + " +
                "   COALESCE(c.VALOR_CARTEIRADIGITAL_CONFERENCIA,0) + " +
                "   COALESCE(c.VALOR_CHEQUE_CONFERENCIA,         0) + " +
                "   COALESCE(c.VALOR_CREDITOLOJA_CONFERENCIA,    0) + " +
                "   COALESCE(c.VALOR_TROCA_CONFERENCIA,          0) + " +
                "   COALESCE(c.VALOR_VALEFUNCIONARIO_CONFERENCIA,0))          AS TOTAL_SALDO, " +
                "  (COALESCE(c.VALOR_DINHEIRO_CONFERENCIA,       0) + " +
                "   COALESCE(c.VALOR_CARTAOCREDITO_CONFERENCIA,  0) + " +
                "   COALESCE(c.VALOR_CARTAODEBITO_CONFERENCIA,   0) + " +
                "   COALESCE(c.VALOR_PIX_CONFERENCIA,            0) + " +
                "   COALESCE(c.VALOR_CARTEIRADIGITAL_CONFERENCIA,0) + " +
                "   COALESCE(c.VALOR_CHEQUE_CONFERENCIA,         0) + " +
                "   COALESCE(c.VALOR_CREDITOLOJA_CONFERENCIA,    0) + " +
                "   COALESCE(c.VALOR_TROCA_CONFERENCIA,          0) + " +
                "   COALESCE(c.VALOR_VALEFUNCIONARIO_CONFERENCIA,0) " +
                "   - COALESCE(v.TOTAL_VENDA, 0) " +
                "   - COALESCE(c.VALOR_INICIAL, 0))                           AS TOTAL_DIFERENCA " +
                "FROM FATURAMENTO.FAT_CAIXA c " +
                // -- subquery: total de vendas e super troco por caixa
                "LEFT JOIN ( " +
                "  SELECT m.CAIXA_ID, " +
                "    SUM(mi.VALOR_INICIAL)    AS TOTAL_VENDA, " +
                "    " + exprSuperTroco + " AS TOTAL_SUPER_TROCO " +
                "  FROM MOVIMENTO.FIN_MOVIMENTO m " +
                "  JOIN MOVIMENTO.FIN_MOVIMENTO_ITEM mi ON mi.MOVIMENTO_ID = m.ID " +
                "  WHERE m.TIPOMOVIMENTO = 'VENDA' AND m.TIPOSITUACAOMOVIMENTO = 'NORMAL' " +
                "  GROUP BY m.CAIXA_ID " +
                ") v ON v.CAIXA_ID = c.ID " +
                // -- subquery: total de sangrias por caixa
                "LEFT JOIN ( " +
                "  SELECT m.CAIXA_ID, " +
                "    SUM(mi.VALOR_INICIAL) AS TOTAL_SANGRIA " +
                "  FROM MOVIMENTO.FIN_MOVIMENTO m " +
                "  JOIN MOVIMENTO.FIN_MOVIMENTO_ITEM mi ON mi.MOVIMENTO_ID = m.ID " +
                "  WHERE m.TIPOMOVIMENTO = 'SANGRIA' " +
                "  GROUP BY m.CAIXA_ID " +
                ") sg ON sg.CAIXA_ID = c.ID" +
                where +
                " ORDER BY c.DATA_ABERTURA DESC FETCH FIRST 500 ROWS ONLY";

            PreparedStatement ps = conn.prepareStatement(sql);
            for (int i = 0; i < vals.size(); i++) ps.setObject(i + 1, vals.get(i));
            ResultSet rs = ps.executeQuery();

            // ── Gerar JSON ───────────────────────────────────────────────────
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            while (rs.next()) {
                if (!first) json.append(",");
                first = false;

                Timestamp ta = rs.getTimestamp("DATA_ABERTURA");
                Timestamp tf = rs.getTimestamp("DATA_FECHAMENTO");

                json.append("{")
                    .append("\"caixa\":\"").append(esc(rs.getString("CAIXA"))).append("\",")
                    .append("\"dataAbertura\":\"").append(ta != null ? sdf.format(ta) : "").append("\",")
                    .append("\"usuarioAbertura\":\"").append(esc(rs.getString("USUARIO_ABERTURA"))).append("\",")
                    .append("\"dataFechamento\":\"").append(tf != null ? sdf.format(tf) : "").append("\",")
                    .append("\"situacao\":\"").append(esc(rs.getString("SITUACAO"))).append("\",")
                    .append("\"totalVenda\":\"").append(rs.getString("TOTAL_VENDA")).append("\",")
                    .append("\"superTroco\":\"").append(rs.getString("TOTAL_SUPER_TROCO")).append("\",")
                    .append("\"sangriaSuprimento\":\"").append(rs.getString("TOTAL_SANGRIA")).append("\",")
                    .append("\"totalSaldo\":\"").append(rs.getString("TOTAL_SALDO")).append("\",")
                    .append("\"diferenca\":\"").append(rs.getString("TOTAL_DIFERENCA")).append("\"")
                    .append("}");
            }
            json.append("]");
            rs.close(); ps.close();
            respJson(ex, 200, json.toString());

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(tratarErro(e)) + "\"}");
        }
    }

    // ─── CONFERÊNCIA DE FECHAMENTO DE CAIXA ──────────────────────────────────
    static void serveFechamento(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204, -1); return; }

        Map<String, String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco       = p.getOrDefault("banco",       "");
        String tipoData    = p.getOrDefault("tipoData",    "ABERTURA");
        String dataIni     = p.getOrDefault("dataIni",     "");
        String dataFim     = p.getOrDefault("dataFim",     "");
        String situacao    = p.getOrDefault("situacao",    "");
        String caixa       = p.getOrDefault("caixa",       "");
        String pagamento   = p.getOrDefault("pagamento",   "");
        String nsu         = p.getOrDefault("nsu",         "");
        String autorizacao = p.getOrDefault("autorizacao", "");

        if (banco.isEmpty()) { respJson(ex, 400, "{\"erro\":\"Banco nao informado\"}"); return; }

        try (Connection conn = conectar(banco)) {

            String colSuperTroco = colExists(conn, "MOVIMENTO", "FIN_MOVIMENTO_ITEM", "VALOR_SUPERTROCO")
                ? "COALESCE(mi.VALOR_SUPERTROCO, 0)" : "0";

            String colData = "FECHAMENTO".equalsIgnoreCase(tipoData)
                ? "c.DATA_FECHAMENTO" : "c.DATA_ABERTURA";

            // ── WHERE RESUMO (FAT_CAIXA direto) ─────────────────────────
            StringBuilder wbR = new StringBuilder(" WHERE 1=1");
            List<Object> bvR  = new ArrayList<>();
            if (!dataIni.isEmpty()) {
                wbR.append(" AND ").append(colData).append(" >= ?");
                bvR.add(Timestamp.valueOf(dataIni + " 00:00:00"));
            }
            if (!dataFim.isEmpty()) {
                wbR.append(" AND ").append(colData).append(" <= ?");
                bvR.add(Timestamp.valueOf(dataFim + " 23:59:59"));
            }
            if ("ABERTO".equalsIgnoreCase(situacao))
                wbR.append(" AND c.DATA_FECHAMENTO IS NULL");
            else if ("FECHADO".equalsIgnoreCase(situacao))
                wbR.append(" AND c.DATA_FECHAMENTO IS NOT NULL");
            if (!caixa.isEmpty()) {
                try {
                    wbR.append(" AND c.SEQUENCEGENERATOR_SEQUENCIA = ?");
                    bvR.add(Long.parseLong(caixa.trim()));
                } catch (NumberFormatException ignore) {}
            }

            // ── WHERE DETALHE (join com movimentos) ──────────────────────
            StringBuilder wd = new StringBuilder(
                " WHERE m.TIPOMOVIMENTO='VENDA' AND m.TIPOSITUACAOMOVIMENTO='NORMAL'");
            List<Object> dv = new ArrayList<>();
            if (!dataIni.isEmpty()) {
                wd.append(" AND ").append(colData).append(" >= ?");
                dv.add(Timestamp.valueOf(dataIni + " 00:00:00"));
            }
            if (!dataFim.isEmpty()) {
                wd.append(" AND ").append(colData).append(" <= ?");
                dv.add(Timestamp.valueOf(dataFim + " 23:59:59"));
            }
            if ("ABERTO".equalsIgnoreCase(situacao))
                wd.append(" AND c.DATA_FECHAMENTO IS NULL");
            else if ("FECHADO".equalsIgnoreCase(situacao))
                wd.append(" AND c.DATA_FECHAMENTO IS NOT NULL");
            if (!caixa.isEmpty()) {
                try {
                    wd.append(" AND c.SEQUENCEGENERATOR_SEQUENCIA = ?");
                    dv.add(Long.parseLong(caixa.trim()));
                } catch (NumberFormatException ignore) {}
            }
            if (!pagamento.isEmpty())   { wd.append(" AND mi.TIPO_COBRANCA = ?");          dv.add(pagamento); }
            if (!nsu.isEmpty())         { wd.append(" AND mi.NSU LIKE ?");                  dv.add("%" + nsu + "%"); }
            if (!autorizacao.isEmpty()) { wd.append(" AND mi.NUMERO_AUTORIZACAO LIKE ?");   dv.add("%" + autorizacao + "%"); }

            SimpleDateFormat sdf  = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            SimpleDateFormat sdfD = new SimpleDateFormat("dd/MM/yyyy");

            // ── Query RESUMO — histórico de FAT_CAIXA ───────────────────
            String sqlR =
                "SELECT c.ID AS CAIXA_ID, " +
                "  c.SEQUENCEGENERATOR_SEQUENCIA AS CAIXA, " +
                "  CASE WHEN c.DATA_FECHAMENTO IS NULL THEN 'ABERTO' ELSE 'FECHADO' END AS STATUS_CAIXA, " +
                "  c.DATA_ABERTURA, c.DATA_FECHAMENTO, " +
                "  COALESCE(c.REPRESENTANTE_ABERTURA_NOME, '') AS OPERADOR, " +
                "  COALESCE(c.VALOR_INICIAL, 0) AS FUNDO, " +
                "  COALESCE(tot.TOTAL_SISTEMA, 0) AS TOTAL_SISTEMA, " +
                "  COALESCE(c.SINC, false) AS SINC_CAIXA, " +
                "  COALESCE(c.VALOR_DINHEIRO_CONFERENCIA,        0) + " +
                "  COALESCE(c.VALOR_CARTAOCREDITO_CONFERENCIA,   0) + " +
                "  COALESCE(c.VALOR_CARTAODEBITO_CONFERENCIA,    0) + " +
                "  COALESCE(c.VALOR_PIX_CONFERENCIA,             0) + " +
                "  COALESCE(c.VALOR_CARTEIRADIGITAL_CONFERENCIA, 0) + " +
                "  COALESCE(c.VALOR_CHEQUE_CONFERENCIA,          0) + " +
                "  COALESCE(c.VALOR_CREDITOLOJA_CONFERENCIA,     0) + " +
                "  COALESCE(c.VALOR_TROCA_CONFERENCIA,           0) + " +
                "  COALESCE(c.VALOR_VALEFUNCIONARIO_CONFERENCIA, 0) AS TOTAL_CONFERENCIA " +
                "FROM FATURAMENTO.FAT_CAIXA c " +
                "LEFT JOIN (" +
                "  SELECT m2.CAIXA_ID, SUM(COALESCE(mi2.VALOR_INICIAL,0)) AS TOTAL_SISTEMA " +
                "  FROM MOVIMENTO.FIN_MOVIMENTO m2 " +
                "  JOIN MOVIMENTO.FIN_MOVIMENTO_ITEM mi2 ON mi2.MOVIMENTO_ID = m2.ID " +
                "  WHERE m2.TIPOMOVIMENTO='VENDA' AND m2.TIPOSITUACAOMOVIMENTO='NORMAL' " +
                "  GROUP BY m2.CAIXA_ID" +
                ") tot ON tot.CAIXA_ID = c.ID" +
                wbR +
                " ORDER BY c.DATA_ABERTURA DESC FETCH FIRST 500 ROWS ONLY";

            PreparedStatement psR = conn.prepareStatement(sqlR);
            for (int i = 0; i < bvR.size(); i++) psR.setObject(i + 1, bvR.get(i));
            ResultSet rsR = psR.executeQuery();

            StringBuilder jR = new StringBuilder("[");
            boolean first = true;
            while (rsR.next()) {
                if (!first) jR.append(",");
                first = false;
                Timestamp ta = rsR.getTimestamp("DATA_ABERTURA");
                Timestamp tf = rsR.getTimestamp("DATA_FECHAMENTO");
                jR.append("{")
                    .append("\"id\":\"").append(esc(rsR.getString("CAIXA_ID"))).append("\",")
                    .append("\"caixa\":\"").append(esc(rsR.getString("CAIXA"))).append("\",")
                    .append("\"status\":\"").append(esc(rsR.getString("STATUS_CAIXA"))).append("\",")
                    .append("\"dataAbertura\":\"").append(ta != null ? sdf.format(ta) : "").append("\",")
                    .append("\"dataFechamento\":\"").append(tf != null ? sdf.format(tf) : "").append("\",")
                    .append("\"operador\":\"").append(esc(rsR.getString("OPERADOR"))).append("\",")
                    .append("\"fundo\":\"").append(rsR.getString("FUNDO")).append("\",")
                    .append("\"totalSistema\":\"").append(rsR.getString("TOTAL_SISTEMA")).append("\",")
                    .append("\"totalConferencia\":\"").append(rsR.getString("TOTAL_CONFERENCIA")).append("\",")
                    .append("\"sinc\":").append(rsR.getBoolean("SINC_CAIXA"))
                    .append("}");
            }
            jR.append("]");
            rsR.close(); psR.close();

            // ── Query DETALHE (por item de pagamento) ────────────────────
            String sqlD =
                "SELECT " +
                "  c.SEQUENCEGENERATOR_SEQUENCIA AS CAIXA, " +
                "  COALESCE(mi.TIPO_COBRANCA, '') AS FORMA_PAGAMENTO, " +
                "  COALESCE(mi.TEF_IDENTIFICACAO, '') AS POS_TEF, " +
                "  CASE WHEN COALESCE(mi.QUANTIDADE_PARCELAS, 0) > 1 THEN 'Parcelado' ELSE 'Vista' END AS VISTA_PARCELADO, " +
                "  COALESCE(m.CODIGO_PEDIDO, '') AS CODIGO_PEDIDO, " +
                "  COALESCE(mi.QUANTIDADE_PARCELAS, 0) AS PRAZOS, " +
                "  CASE WHEN COALESCE(mi.TEF_TIPO_PARCELAMENTO,'') IN ('UNKNOWN','') THEN '' ELSE mi.TEF_TIPO_PARCELAMENTO END AS TIPO_PARCELAMENTO, " +
                "  m.DATA_ABERTURA AS HORARIO, " +
                "  mi.VENCIMENTO AS VENCIMENTO, " +
                "  TRIM(COALESCE(mi.DESCRICAO_CARTAO, '')) AS DESCRICAO_CARTAO, " +
                "  COALESCE(TRIM(mi.CREDENCIADORA_PESSOA_NOMERAZAO), TRIM(mi.NOME_REDE_ADQUIRENTE), '') AS CREDENCIADORA, " +
                "  COALESCE(mi.NSU, '') AS TEF_NSU, " +
                "  COALESCE(mi.NUMERO_AUTORIZACAO, '') AS TEF_AUTORIZACAO, " +
                "  " + colSuperTroco + " AS SUPER_TROCO, " +
                "  COALESCE(mi.VALOR_INICIAL, 0) AS VALOR_BRUTO, " +
                "  COALESCE(mi.VALOR_TAXA_SERVICO, 0) AS TAXA_ADM, " +
                "  (COALESCE(mi.VALOR_INICIAL, 0) - COALESCE(mi.VALOR_TAXA_SERVICO, 0)) AS VALOR_LIQUIDO " +
                "FROM FATURAMENTO.FAT_CAIXA c " +
                "JOIN MOVIMENTO.FIN_MOVIMENTO m ON m.CAIXA_ID = c.ID " +
                "JOIN MOVIMENTO.FIN_MOVIMENTO_ITEM mi ON mi.MOVIMENTO_ID = m.ID" +
                wd +
                " ORDER BY m.DATA_ABERTURA DESC FETCH FIRST 2000 ROWS ONLY";

            PreparedStatement psD = conn.prepareStatement(sqlD);
            for (int i = 0; i < dv.size(); i++) psD.setObject(i + 1, dv.get(i));
            ResultSet rsD = psD.executeQuery();

            StringBuilder jD = new StringBuilder("[");
            first = true;
            while (rsD.next()) {
                if (!first) jD.append(",");
                first = false;

                Timestamp th = rsD.getTimestamp("HORARIO");
                String vencStr = "";
                try {
                    Timestamp tv = rsD.getTimestamp("VENCIMENTO");
                    if (tv != null) vencStr = sdfD.format(tv);
                } catch (Exception ignored) {
                    String tv = rsD.getString("VENCIMENTO");
                    if (tv != null) vencStr = tv.trim();
                }

                jD.append("{")
                    .append("\"caixa\":\"").append(esc(rsD.getString("CAIXA"))).append("\",")
                    .append("\"formaPagamento\":\"").append(esc(rsD.getString("FORMA_PAGAMENTO"))).append("\",")
                    .append("\"posTef\":\"").append(esc(rsD.getString("POS_TEF"))).append("\",")
                    .append("\"vistaParcelado\":\"").append(esc(rsD.getString("VISTA_PARCELADO"))).append("\",")
                    .append("\"codigoPedido\":\"").append(esc(rsD.getString("CODIGO_PEDIDO"))).append("\",")
                    .append("\"prazos\":\"").append(esc(rsD.getString("PRAZOS"))).append("\",")
                    .append("\"tipoParcelamento\":\"").append(esc(rsD.getString("TIPO_PARCELAMENTO"))).append("\",")
                    .append("\"horario\":\"").append(th != null ? sdf.format(th) : "").append("\",")
                    .append("\"vencimento\":\"").append(esc(vencStr)).append("\",")
                    .append("\"descritivoCartao\":\"").append(esc(rsD.getString("DESCRICAO_CARTAO"))).append("\",")
                    .append("\"credenciadora\":\"").append(esc(rsD.getString("CREDENCIADORA"))).append("\",")
                    .append("\"nsu\":\"").append(esc(rsD.getString("TEF_NSU"))).append("\",")
                    .append("\"autorizacao\":\"").append(esc(rsD.getString("TEF_AUTORIZACAO"))).append("\",")
                    .append("\"superTroco\":\"").append(rsD.getString("SUPER_TROCO")).append("\",")
                    .append("\"valorBruto\":\"").append(rsD.getString("VALOR_BRUTO")).append("\",")
                    .append("\"taxaAdm\":\"").append(rsD.getString("TAXA_ADM")).append("\",")
                    .append("\"valorLiquido\":\"").append(rsD.getString("VALOR_LIQUIDO")).append("\"")
                    .append("}");
            }
            jD.append("]");
            rsD.close(); psD.close();

            respJson(ex, 200, "{\"resumo\":" + jR + ",\"detalhe\":" + jD + "}");

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(tratarErro(e)) + "\"}");
        }
    }

    static boolean colExists(Connection conn, String schema, String table, String col) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) FROM SYS.SYSCOLUMNS " +
                "WHERE TABLESCHEMANAME=? AND TABLENAME=? AND COLUMNNAME=?")) {
            ps.setString(1, schema); ps.setString(2, table); ps.setString(3, col);
            ResultSet rs = ps.executeQuery();
            boolean found = rs.next() && rs.getInt(1) > 0;
            rs.close(); return found;
        } catch (Exception e) { return false; }
    }

    static String findCol(Set<String> cols, String... candidates) {
        for (String c : candidates)
            if (cols.contains(c.toUpperCase())) return c;
        return null;
    }

    static String getStr(ResultSet rs, String col) {
        if (col == null) return "";
        try { String v = rs.getString(col); return v != null ? v.trim() : ""; }
        catch (Exception e) { return ""; }
    }

    static String fmtTsCol(ResultSet rs, String col) {
        if (col == null) return "";
        try {
            Timestamp ts = rs.getTimestamp(col);
            return ts != null ? new SimpleDateFormat("dd/MM/yyyy HH:mm").format(ts) : "";
        } catch (Exception e) {
            try { String v = rs.getString(col); return v != null ? v.trim() : ""; }
            catch (Exception e2) { return ""; }
        }
    }

    // ─── DIAGNÓSTICO DE BANCO ────────────────────────────────────────────────
    static void serveDiag(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204,-1); return; }
        Map<String,String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco = p.getOrDefault("banco","");
        if (banco.isEmpty()) { respJson(ex,400,"{\"erro\":\"Informe ?banco=NOME\"}"); return; }

        StringBuilder sb = new StringBuilder("{");

        try (Connection conn = conectar(banco)) {

            // ── Tabelas de interesse ──────────────────────────────────────────
            String[] interesse = {
                "FATURAMENTO.FAT_CAIXA",
                "FATURAMENTO.FAT_HISTORICO_CAIXA_VALOR",
                "ARARATI.FAT_CAIXA_FAT_HISTORICO_CAIXA_VALOR",
                "MOVIMENTO.FIN_MOVIMENTO",
                "MOVIMENTO.FIN_MOVIMENTO_ITEM",
                "FATURAMENTO.FAT_PEDIDO_VENDA",
                "FATURAMENTO.FAT_PEDIDO_FORMA_PAGAMENTO"
            };

            sb.append("\"detalhes\":{");
            boolean ftop = true;

            for (String tab : interesse) {
                // Usa FETCH FIRST 3 ROWS ONLY + ResultSetMetaData (igual QueryColunas2.java)
                ResultSet rs = null;
                ResultSetMetaData md = null;
                try {
                    rs = conn.createStatement().executeQuery(
                        "SELECT * FROM " + tab + " FETCH FIRST 3 ROWS ONLY");
                    md = rs.getMetaData();
                } catch (Exception e) {
                    // tabela não existe ou sem acesso
                    continue;
                }

                if (!ftop) sb.append(","); ftop = false;
                sb.append("\"").append(esc(tab)).append("\":{");

                // colunas com tipo
                sb.append("\"colunas\":[");
                for (int i = 1; i <= md.getColumnCount(); i++) {
                    if (i > 1) sb.append(",");
                    sb.append("{\"n\":\"").append(esc(md.getColumnName(i)))
                      .append("\",\"t\":\"").append(esc(md.getColumnTypeName(i))).append("\"}");
                }
                sb.append("],");

                // amostra de dados
                sb.append("\"amostra\":[");
                boolean fr = true;
                while (rs.next()) {
                    if (!fr) sb.append(","); fr = false;
                    sb.append("{");
                    for (int i = 1; i <= md.getColumnCount(); i++) {
                        if (i > 1) sb.append(",");
                        String v = rs.getString(i);
                        if (v != null && v.length() > 120) v = v.substring(0, 120) + "...";
                        sb.append("\"").append(esc(md.getColumnName(i))).append("\":")
                          .append(v == null ? "null" : "\"" + esc(v) + "\"");
                    }
                    sb.append("}");
                }
                rs.close();
                sb.append("]");
                sb.append("}");
            }
            sb.append("},");

            // ── Contagens ────────────────────────────────────────────────────
            sb.append("\"contagens\":{");
            boolean fc = true;
            for (String tab : interesse) {
                try {
                    ResultSet rc = conn.createStatement().executeQuery("SELECT COUNT(*) FROM " + tab);
                    rc.next();
                    if (!fc) sb.append(","); fc = false;
                    sb.append("\"").append(esc(tab)).append("\":").append(rc.getLong(1));
                    rc.close();
                } catch (Exception ignored) {}
            }
            sb.append("}");

        } catch (Exception e) {
            sb.append("\"erro\":\"").append(esc(e.getMessage())).append("\"");
        }

        sb.append("}");
        respJson(ex, 200, sb.toString());
    }

    // ─── VALIDAÇÃO DA QUERY PROPOSTA ─────────────────────────────────────────
    static void serveDiagQuery(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204,-1); return; }
        Map<String,String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco = p.getOrDefault("banco","");
        if (banco.isEmpty()) { respJson(ex,400,"{\"erro\":\"Informe ?banco=NOME\"}"); return; }

        StringBuilder sb = new StringBuilder("{");
        try (Connection conn = conectar(banco)) {

            // ── 1. Quantos TIPOMOVIMENTO distintos existem? ──────────────────
            sb.append("\"tipos_movimento\":[");
            ResultSet r1 = conn.createStatement().executeQuery(
                "SELECT TIPOMOVIMENTO, TIPOSITUACAOMOVIMENTO, COUNT(*) AS QTD " +
                "FROM MOVIMENTO.FIN_MOVIMENTO GROUP BY TIPOMOVIMENTO, TIPOSITUACAOMOVIMENTO ORDER BY 1,2");
            boolean f=true;
            while(r1.next()){ if(!f)sb.append(",");f=false;
                sb.append("{\"tipo\":\"").append(esc(r1.getString(1)))
                  .append("\",\"sit\":\"").append(esc(r1.getString(2)))
                  .append("\",\"qtd\":").append(r1.getLong(3)).append("}"); }
            r1.close(); sb.append("],");

            // ── 2. Verificar FK: todos CAIXA_ID de FIN_MOVIMENTO existem em FAT_CAIXA? ──
            ResultSet r2 = conn.createStatement().executeQuery(
                "SELECT COUNT(*) FROM MOVIMENTO.FIN_MOVIMENTO m " +
                "WHERE NOT EXISTS (SELECT 1 FROM FATURAMENTO.FAT_CAIXA c WHERE c.ID = m.CAIXA_ID)");
            r2.next();
            sb.append("\"movimentos_sem_caixa\":").append(r2.getLong(1)).append(",");
            r2.close();

            // ── 3. Quantos caixas têm movimentos VENDA? ──────────────────────
            ResultSet r3 = conn.createStatement().executeQuery(
                "SELECT COUNT(DISTINCT CAIXA_ID) FROM MOVIMENTO.FIN_MOVIMENTO WHERE TIPOMOVIMENTO='VENDA'");
            r3.next();
            sb.append("\"caixas_com_venda\":").append(r3.getLong(1)).append(",");
            r3.close();

            // ── 4. Rodar a query FINAL proposta — 5 linhas ───────────────────
            sb.append("\"amostra_query_final\":[");
            ResultSet r4 = conn.createStatement().executeQuery(
                "SELECT " +
                "  c.SEQUENCEGENERATOR_SEQUENCIA AS CAIXA, " +
                "  c.DATA_ABERTURA, " +
                "  c.REPRESENTANTE_ABERTURA_NOME AS USUARIO_ABERTURA, " +
                "  c.DATA_FECHAMENTO, " +
                "  CASE WHEN c.DATA_FECHAMENTO IS NULL THEN 'ABERTO' ELSE 'FECHADO' END AS SITUACAO, " +
                "  COALESCE(v.TOTAL_VENDA, 0) AS TOTAL_VENDA, " +
                "  COALESCE(v.TOTAL_SUPER_TROCO, 0) AS TOTAL_SUPER_TROCO, " +
                "  COALESCE(sg.TOTAL_SANGRIA, 0) AS TOTAL_SANGRIA, " +
                "  (COALESCE(c.VALOR_DINHEIRO_CONFERENCIA,0) + COALESCE(c.VALOR_CARTAOCREDITO_CONFERENCIA,0) + " +
                "   COALESCE(c.VALOR_CARTAODEBITO_CONFERENCIA,0) + COALESCE(c.VALOR_PIX_CONFERENCIA,0) + " +
                "   COALESCE(c.VALOR_CARTEIRADIGITAL_CONFERENCIA,0) + COALESCE(c.VALOR_CHEQUE_CONFERENCIA,0) + " +
                "   COALESCE(c.VALOR_CREDITOLOJA_CONFERENCIA,0) + COALESCE(c.VALOR_TROCA_CONFERENCIA,0) + " +
                "   COALESCE(c.VALOR_VALEFUNCIONARIO_CONFERENCIA,0)) AS TOTAL_SALDO, " +
                "  (COALESCE(v.TOTAL_VENDA,0) - " +
                "   (COALESCE(c.VALOR_DINHEIRO_CONFERENCIA,0) + COALESCE(c.VALOR_CARTAOCREDITO_CONFERENCIA,0) + " +
                "    COALESCE(c.VALOR_CARTAODEBITO_CONFERENCIA,0) + COALESCE(c.VALOR_PIX_CONFERENCIA,0) + " +
                "    COALESCE(c.VALOR_CARTEIRADIGITAL_CONFERENCIA,0) + COALESCE(c.VALOR_CHEQUE_CONFERENCIA,0) + " +
                "    COALESCE(c.VALOR_CREDITOLOJA_CONFERENCIA,0) + COALESCE(c.VALOR_TROCA_CONFERENCIA,0) + " +
                "    COALESCE(c.VALOR_VALEFUNCIONARIO_CONFERENCIA,0))) AS TOTAL_DIFERENCA " +
                "FROM FATURAMENTO.FAT_CAIXA c " +
                "LEFT JOIN ( " +
                "  SELECT m.CAIXA_ID, SUM(mi.VALOR_INICIAL) AS TOTAL_VENDA, " +
                (colExists(conn, "MOVIMENTO", "FIN_MOVIMENTO_ITEM", "VALOR_SUPERTROCO")
                    ? "SUM(mi.VALOR_SUPERTROCO)" : "0") + " AS TOTAL_SUPER_TROCO " +
                "  FROM MOVIMENTO.FIN_MOVIMENTO m " +
                "  JOIN MOVIMENTO.FIN_MOVIMENTO_ITEM mi ON mi.MOVIMENTO_ID = m.ID " +
                "  WHERE m.TIPOMOVIMENTO='VENDA' AND m.TIPOSITUACAOMOVIMENTO='NORMAL' " +
                "  GROUP BY m.CAIXA_ID " +
                ") v ON v.CAIXA_ID = c.ID " +
                "LEFT JOIN ( " +
                "  SELECT m.CAIXA_ID, SUM(mi.VALOR_INICIAL) AS TOTAL_SANGRIA " +
                "  FROM MOVIMENTO.FIN_MOVIMENTO m " +
                "  JOIN MOVIMENTO.FIN_MOVIMENTO_ITEM mi ON mi.MOVIMENTO_ID = m.ID " +
                "  WHERE m.TIPOMOVIMENTO='SANGRIA' " +
                "  GROUP BY m.CAIXA_ID " +
                ") sg ON sg.CAIXA_ID = c.ID " +
                "ORDER BY c.DATA_ABERTURA DESC FETCH FIRST 5 ROWS ONLY");
            ResultSetMetaData md = r4.getMetaData();
            boolean fr=true;
            while(r4.next()){ if(!fr)sb.append(",");fr=false;
                sb.append("{");
                for(int i=1;i<=md.getColumnCount();i++){
                    if(i>1)sb.append(",");
                    String v=r4.getString(i);
                    sb.append("\"").append(esc(md.getColumnName(i))).append("\":")
                      .append(v==null?"null":"\""+esc(v)+"\"");
                }
                sb.append("}");
            }
            r4.close(); sb.append("],");

            // ── 5. Caixas sem NENHUM movimento (possível dado inconsistente) ──
            ResultSet r5 = conn.createStatement().executeQuery(
                "SELECT COUNT(*) FROM FATURAMENTO.FAT_CAIXA c " +
                "WHERE NOT EXISTS (SELECT 1 FROM MOVIMENTO.FIN_MOVIMENTO m WHERE m.CAIXA_ID=c.ID)");
            r5.next();
            sb.append("\"caixas_sem_movimento\":").append(r5.getLong(1)).append(",");
            r5.close();

            // ── 6. Colunas de FAT_CAIXA (para identificar campo de número do caixa) ──
            sb.append("\"colunas_fat_caixa\":[");
            try {
                ResultSet rc = conn.createStatement().executeQuery(
                    "SELECT sc.COLUMNNAME, sc.COLUMNTYPE " +
                    "FROM SYS.SYSCOLUMNS sc " +
                    "JOIN SYS.SYSTABLES st ON sc.REFERENCEID = st.TABLEID " +
                    "JOIN SYS.SYSSCHEMAS ss ON st.SCHEMAID = ss.SCHEMAID " +
                    "WHERE st.TABLENAME = 'FAT_CAIXA' AND ss.SCHEMANAME = 'FATURAMENTO' " +
                    "ORDER BY sc.COLUMNNUMBER");
                boolean fc = true;
                while (rc.next()) {
                    if (!fc) sb.append(","); fc = false;
                    sb.append("{\"col\":\"").append(esc(rc.getString(1)))
                      .append("\",\"tipo\":\"").append(esc(rc.getString(2))).append("\"}");
                }
                rc.close();
            } catch(Exception ec) { sb.append("\"erro_cols\":\"").append(esc(ec.getMessage())).append("\""); }
            sb.append("],");

            // ── 7. Amostra 1 linha de FAT_CAIXA com todos os campos visíveis ──
            sb.append("\"amostra_fat_caixa_1linha\":[");
            try {
                ResultSet rs7 = conn.createStatement().executeQuery(
                    "SELECT * FROM FATURAMENTO.FAT_CAIXA ORDER BY DATA_ABERTURA DESC FETCH FIRST 1 ROWS ONLY");
                ResultSetMetaData md7 = rs7.getMetaData();
                if (rs7.next()) {
                    sb.append("{");
                    for (int i = 1; i <= md7.getColumnCount(); i++) {
                        if (i > 1) sb.append(",");
                        String v = rs7.getString(i);
                        sb.append("\"").append(esc(md7.getColumnName(i))).append("\":")
                          .append(v == null ? "null" : "\"" + esc(v) + "\"");
                    }
                    sb.append("}");
                }
                rs7.close();
            } catch(Exception e7) { sb.append("\"erro\":\"").append(esc(e7.getMessage())).append("\""); }
            sb.append("]");

        } catch(Exception e){
            sb.append("\"erro\":\"").append(esc(e.getMessage())).append("\"");
        }
        sb.append("}");
        respJson(ex,200,sb.toString());
    }

    // ─── CORRIGIR NOTA (NCM + CBS/IBS) E RETRANSMITIR ────────────────────────
    static void serveCorrigirNota(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204,-1); return; }
        if (!"POST".equals(ex.getRequestMethod()))   { ex.sendResponseHeaders(405,-1); return; }

        String body  = new String(readAllBytes(ex.getRequestBody()), StandardCharsets.UTF_8);
        String banco = extraiJson(body, "banco");
        String id    = extraiJson(body, "id");
        if (banco.isEmpty() || id.isEmpty()) {
            respJson(ex, 400, "{\"erro\":\"Parametros invalidos\"}"); return;
        }
        double pCBS = extraiDoubleJson(body, "pCBS");
        double pIBS = extraiDoubleJson(body, "pIBS");
        Map<String,String> ncmMap = extraiJsonObj(body, "ncmMap");

        try (Connection conn = conectar(banco)) {
            // Dados da nota
            PreparedStatement ps = conn.prepareStatement(
                "SELECT IDE_NNF, IDE_MOD, IDE_CUF, EMIT_ENDERUF, CHAVE_ACESSO, NUMERO_TENTATIVAS " +
                "FROM NFE.NFE_NOTA_FISCAL_ELETRONICA WHERE ID=?");
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) { respJson(ex, 404, "{\"erro\":\"Nota nao encontrada\"}"); return; }
            String numero     = rs.getString("IDE_NNF");
            String mod        = rs.getString("IDE_MOD");
            String cuf        = rs.getString("IDE_CUF");
            String uf         = rs.getString("EMIT_ENDERUF");
            String chave      = rs.getString("CHAVE_ACESSO");
            int    tentativas = rs.getInt("NUMERO_TENTATIVAS");
            rs.close(); ps.close();

            // XML original assinado
            byte[] assinadoBytes = xmlAssinado(conn, id);
            if (assinadoBytes == null)
                throw new Exception("XML assinado nao encontrado para ID=" + id);

            String xmlOriginal = new String(assinadoBytes, StandardCharsets.UTF_8).trim();
            if (xmlOriginal.startsWith("<?xml"))
                xmlOriginal = xmlOriginal.substring(xmlOriginal.indexOf("?>") + 2).trim();

            // Corrigir e re-assinar
            CertInfo ci = carregarCertInfo(conn);
            String xmlCorrigido = corrigirXmlNota(xmlOriginal, ncmMap, pCBS, pIBS, ci);

            // Strip declaration para SOAP
            String nfeXml = xmlCorrigido.trim();
            if (nfeXml.startsWith("<?xml")) nfeXml = nfeXml.substring(nfeXml.indexOf("?>") + 2).trim();

            // Montar e enviar ao SEFAZ
            String idLote  = String.valueOf(System.currentTimeMillis()).substring(0, 13);
            String indSinc = "65".equals(mod) ? "1" : "0";
            String wsdlNs  = "http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4";
            String enviNFe =
                "<enviNFe xmlns=\"http://www.portalfiscal.inf.br/nfe\" versao=\"4.00\">" +
                "<idLote>" + idLote + "</idLote><indSinc>" + indSinc + "</indSinc>" +
                nfeXml + "</enviNFe>";
            String soap =
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" +
                " xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"" +
                " xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">" +
                "<soap12:Header><nfeCabecMsg xmlns=\"" + wsdlNs + "\">" +
                "<cUF>" + cuf + "</cUF><versaoDados>4.00</versaoDados>" +
                "</nfeCabecMsg></soap12:Header><soap12:Body>" +
                "<nfeDadosMsg xmlns=\"" + wsdlNs + "\">" + enviNFe + "</nfeDadosMsg></soap12:Body></soap12:Envelope>";

            String wsUrl = urlWebservice(conn, uf, "AUTORIZACAO");
            if (wsUrl == null) throw new Exception("URL de autorizacao nao encontrada para UF=" + uf);

            SSLContext sslCtx = criarSSLContext(ci);
            String action = "http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4/nfeAutorizacaoLote";
            String resp   = chamarSefaz(sslCtx, wsUrl, action, soap);

            String cStatLote   = extrairTag(resp, "cStat");
            String xMotivoLote = extrairTag(resp, "xMotivo");
            String protNFeXml  = extrairTagFull(resp, "protNFe");
            String cStat       = protNFeXml.isEmpty() ? cStatLote : extrairTag(protNFeXml, "cStat");
            String xMotivo     = protNFeXml.isEmpty() ? xMotivoLote : extrairTag(protNFeXml, "xMotivo");
            String nProt       = extrairTag(protNFeXml, "nProt");
            String dhRecbto    = extrairTag(protNFeXml, "dhRecbto");
            if (dhRecbto.isEmpty()) dhRecbto = extrairTag(resp, "dhRecbto");

            boolean autorizado = "100".equals(cStat) || "150".equals(cStat);

            // Incrementar tentativas
            try (PreparedStatement upd = conn.prepareStatement(
                    "UPDATE NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                    "SET NUMERO_TENTATIVAS=?, DATAATUALIZACAO=CURRENT_TIMESTAMP WHERE ID=?")) {
                upd.setInt(1, tentativas + 1); upd.setString(2, id); upd.executeUpdate();
            }

            if (autorizado) {
                String procNFe = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                    "<nfeProc xmlns=\"http://www.portalfiscal.inf.br/nfe\" versao=\"4.00\">" +
                    nfeXml + protNFeXml + "</nfeProc>";
                byte[] procBytes = procNFe.getBytes(StandardCharsets.UTF_8);
                String distId = java.util.UUID.randomUUID().toString();
                try (PreparedStatement ins = conn.prepareStatement(
                        "INSERT INTO NFE.NFE_DISTRIBUICAO_XML " +
                        "(ID,CHAVE_ACESSO,DATAATUALIZACAO,DHRECEBTO,TIPO_DISTRIBUICAO," +
                        "NPROT,NSEQEVENTO,SINC,TPEVENTO,XML_ARQUIVO,NOTA_FISCAL_ELETRONICA_ID) " +
                        "VALUES (?,?,CURRENT_TIMESTAMP,?,'AUTORIZACAO',?,null,false,null,?,?)")) {
                    ins.setString(1, distId); ins.setString(2, chave);
                    ins.setString(3, dhRecbto); ins.setString(4, nProt);
                    ins.setBytes(5, procBytes); ins.setString(6, id);
                    ins.executeUpdate();
                }
                try (PreparedStatement upd = conn.prepareStatement(
                        "UPDATE NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                        "SET TIPO_SITUACAO='AUTORIZADO', PROTOCOLOAUTORIZACAO=?, " +
                        "DATA_HORA_AUTORIZACAO=CURRENT_TIMESTAMP WHERE ID=?")) {
                    upd.setString(1, nProt); upd.setString(2, id); upd.executeUpdate();
                }
            }

            respJson(ex, 200,
                "{\"numero\":\"" + esc(numero) + "\"," +
                "\"cStat\":\"" + esc(cStat) + "\"," +
                "\"xMotivo\":\"" + esc(xMotivo) + "\"," +
                "\"autorizado\":" + autorizado + "," +
                "\"tentativas\":" + (tentativas + 1) + "}");

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage() != null ? e.getMessage() : e.toString()) + "\"}");
        }
    }

    static String corrigirXmlNota(String xmlOriginal, Map<String,String> ncmMap,
                                   double pCBS, double pIBS, CertInfo ci) throws Exception {
        final String NFE_NS = "http://www.portalfiscal.inf.br/nfe";
        final String SIG_NS = "http://www.w3.org/2000/09/xmldsig#";

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        Document doc = dbf.newDocumentBuilder().parse(
            new ByteArrayInputStream(xmlOriginal.getBytes(StandardCharsets.UTF_8)));

        // Remove assinatura antiga
        NodeList sigs = doc.getElementsByTagNameNS(SIG_NS, "Signature");
        while (sigs.getLength() > 0) {
            Node s = sigs.item(0);
            s.getParentNode().removeChild(s);
        }

        // Corrigir NCM
        if (!ncmMap.isEmpty()) {
            NodeList ncms = doc.getElementsByTagNameNS(NFE_NS, "NCM");
            for (int i = 0; i < ncms.getLength(); i++) {
                String old = ncms.item(i).getTextContent().trim();
                if (ncmMap.containsKey(old)) ncms.item(i).setTextContent(ncmMap.get(old));
            }
        }

        // Adicionar CBS/IBS em cada produto
        if (pCBS > 0 || pIBS > 0) {
            NodeList dets = doc.getElementsByTagNameNS(NFE_NS, "det");
            for (int i = 0; i < dets.getLength(); i++) {
                Element det = (Element) dets.item(i);
                NodeList vpl = det.getElementsByTagNameNS(NFE_NS, "vProd");
                if (vpl.getLength() == 0) continue;
                double vProd;
                try { vProd = Double.parseDouble(vpl.item(0).getTextContent().trim()); }
                catch (NumberFormatException e) { continue; }

                NodeList il = det.getElementsByTagNameNS(NFE_NS, "imposto");
                if (il.getLength() == 0) continue;
                Element imposto = (Element) il.item(0);

                // Remove CBS/IBS anteriores se existirem
                for (String tag : new String[]{"CBS","IBS"}) {
                    NodeList old = imposto.getElementsByTagNameNS(NFE_NS, tag);
                    while (old.getLength() > 0) imposto.removeChild(old.item(0));
                }

                if (pCBS > 0) {
                    BigDecimal vCBS = BigDecimal.valueOf(vProd)
                        .multiply(BigDecimal.valueOf(pCBS))
                        .divide(BigDecimal.valueOf(100), 2, java.math.RoundingMode.HALF_UP);
                    Element cbs = doc.createElementNS(NFE_NS, "CBS");
                    xmlAddText(doc, cbs, NFE_NS, "CST",  "01");
                    xmlAddText(doc, cbs, NFE_NS, "vBC",  fmt2Dec(vProd));
                    xmlAddText(doc, cbs, NFE_NS, "pCBS", fmt2Dec(pCBS));
                    xmlAddText(doc, cbs, NFE_NS, "vCBS", vCBS.toPlainString());
                    imposto.appendChild(cbs);
                }
                if (pIBS > 0) {
                    BigDecimal vIBS = BigDecimal.valueOf(vProd)
                        .multiply(BigDecimal.valueOf(pIBS))
                        .divide(BigDecimal.valueOf(100), 2, java.math.RoundingMode.HALF_UP);
                    Element ibs = doc.createElementNS(NFE_NS, "IBS");
                    xmlAddText(doc, ibs, NFE_NS, "CST",  "01");
                    xmlAddText(doc, ibs, NFE_NS, "vBC",  fmt2Dec(vProd));
                    xmlAddText(doc, ibs, NFE_NS, "pIBS", fmt2Dec(pIBS));
                    xmlAddText(doc, ibs, NFE_NS, "vIBS", vIBS.toPlainString());
                    imposto.appendChild(ibs);
                }
            }
        }

        // Obter Id do infNFe para assinar
        NodeList infNFes = doc.getElementsByTagNameNS(NFE_NS, "infNFe");
        if (infNFes.getLength() == 0) throw new Exception("infNFe nao encontrado no XML");
        String refId = ((Element) infNFes.item(0)).getAttribute("Id");
        if (refId.isEmpty()) throw new Exception("Atributo Id do infNFe nao encontrado");

        // Re-assinar
        assinarDocumento(doc, refId, ci.pk, ci.cert);
        return docToString(doc);
    }

    static void xmlAddText(Document doc, Element parent, String ns, String tag, String text) {
        Element el = doc.createElementNS(ns, tag);
        el.setTextContent(text);
        parent.appendChild(el);
    }

    static String fmt2Dec(double v) {
        return String.format(java.util.Locale.US, "%.2f", v);
    }

    static double extraiDoubleJson(String json, String key) {
        String p = "\"" + key + "\":";
        int i = json.indexOf(p);
        if (i < 0) return 0.0;
        i += p.length();
        while (i < json.length() && json.charAt(i) == ' ') i++;
        if (i >= json.length()) return 0.0;
        boolean quoted = json.charAt(i) == '"';
        if (quoted) i++;
        int j = i;
        while (j < json.length() && (Character.isDigit(json.charAt(j)) || json.charAt(j) == '.' || json.charAt(j) == '-')) j++;
        try { return Double.parseDouble(json.substring(i, j)); } catch (Exception e) { return 0.0; }
    }

    static Map<String,String> extraiJsonObj(String json, String key) {
        Map<String,String> map = new LinkedHashMap<>();
        String s = "\"" + key + "\":{";
        int i = json.indexOf(s);
        if (i < 0) return map;
        i += s.length();
        int depth = 1, start = i;
        while (i < json.length() && depth > 0) {
            char c = json.charAt(i++);
            if (c == '{') depth++; else if (c == '}') depth--;
        }
        String inner = json.substring(start, i - 1);
        int pos = 0;
        while (pos < inner.length()) {
            int q1 = inner.indexOf('"', pos);   if (q1 < 0) break;
            int q2 = inner.indexOf('"', q1+1);  if (q2 < 0) break;
            String k = inner.substring(q1+1, q2);
            int col = inner.indexOf(':', q2+1); if (col < 0) break;
            int q3 = inner.indexOf('"', col+1); if (q3 < 0) break;
            int q4 = inner.indexOf('"', q3+1);  if (q4 < 0) break;
            String v = inner.substring(q3+1, q4);
            if (!k.isEmpty()) map.put(k, v);
            pos = q4 + 1;
        }
        return map;
    }

    // ─── POPUP CONFERÊNCIA DE CAIXA ──────────────────────────────────────────
    static void serveFechamentoPopup(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204,-1); return; }
        Map<String,String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco    = p.getOrDefault("banco","");
        String caixaStr = p.getOrDefault("caixa","");
        if (banco.isEmpty() || caixaStr.isEmpty()) {
            respJson(ex,400,"{\"erro\":\"Informe ?banco=NOME&caixa=NUM\"}"); return;
        }
        long caixaNum;
        try { caixaNum = Long.parseLong(caixaStr.trim()); }
        catch (NumberFormatException e) { respJson(ex,400,"{\"erro\":\"caixa invalido\"}"); return; }

        try (Connection conn = conectar(banco)) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

            // ── Query 1: dados do caixa + valores de conferência ─────────────
            PreparedStatement ps1 = conn.prepareStatement(
                "SELECT c.DATA_ABERTURA, c.DATA_FECHAMENTO, " +
                "  COALESCE(c.REPRESENTANTE_ABERTURA_NOME,'') AS OPERADOR, " +
                "  COALESCE(c.VALOR_INICIAL,                 0) AS FUNDO, " +
                "  COALESCE(c.VALOR_DINHEIRO_CONFERENCIA,    0) AS CONF_DINHEIRO, " +
                "  COALESCE(c.VALOR_CARTAOCREDITO_CONFERENCIA, 0) AS CONF_CREDITO, " +
                "  COALESCE(c.VALOR_CARTAODEBITO_CONFERENCIA,  0) AS CONF_DEBITO, " +
                "  COALESCE(c.VALOR_PIX_CONFERENCIA,           0) AS CONF_PIX, " +
                "  COALESCE(c.VALOR_CARTEIRADIGITAL_CONFERENCIA,0) AS CONF_CARTEIRA, " +
                "  COALESCE(c.VALOR_CHEQUE_CONFERENCIA,        0) AS CONF_CHEQUE, " +
                "  COALESCE(c.VALOR_CREDITOLOJA_CONFERENCIA,   0) AS CONF_CREDITOLOJA, " +
                "  COALESCE(c.VALOR_TROCA_CONFERENCIA,         0) AS CONF_TROCA, " +
                "  COALESCE(c.VALOR_VALEFUNCIONARIO_CONFERENCIA,0) AS CONF_VALEFUNC " +
                "FROM FATURAMENTO.FAT_CAIXA c " +
                "WHERE c.SEQUENCEGENERATOR_SEQUENCIA = ?");
            ps1.setLong(1, caixaNum);
            ResultSet rs1 = ps1.executeQuery();
            if (!rs1.next()) {
                rs1.close(); ps1.close();
                respJson(ex,404,"{\"erro\":\"Caixa nao encontrado\"}"); return;
            }

            Timestamp ta = rs1.getTimestamp("DATA_ABERTURA");
            Timestamp tf = rs1.getTimestamp("DATA_FECHAMENTO");
            StringBuilder sb = new StringBuilder("{");
            sb.append("\"dataAbertura\":\"").append(ta != null ? sdf.format(ta) : "").append("\",");
            sb.append("\"dataFechamento\":\"").append(tf != null ? sdf.format(tf) : "Aberto").append("\",");
            sb.append("\"operador\":\"").append(esc(rs1.getString("OPERADOR"))).append("\",");
            sb.append("\"fundo\":\"").append(rs1.getString("FUNDO")).append("\",");
            sb.append("\"conferencia\":{");
            sb.append("\"DINHEIRO\":\"").append(rs1.getString("CONF_DINHEIRO")).append("\",");
            sb.append("\"CARTAO_CREDITO\":\"").append(rs1.getString("CONF_CREDITO")).append("\",");
            sb.append("\"CARTAO_DEBITO\":\"").append(rs1.getString("CONF_DEBITO")).append("\",");
            sb.append("\"PIX\":\"").append(rs1.getString("CONF_PIX")).append("\",");
            sb.append("\"CARTAO_CARTEIRADIGITAL\":\"").append(rs1.getString("CONF_CARTEIRA")).append("\",");
            sb.append("\"CHEQUE\":\"").append(rs1.getString("CONF_CHEQUE")).append("\",");
            sb.append("\"CREDITO_LOJA\":\"").append(rs1.getString("CONF_CREDITOLOJA")).append("\",");
            sb.append("\"VALE_TROCA\":\"").append(rs1.getString("CONF_TROCA")).append("\",");
            sb.append("\"VALE_FUNCIONARIO\":\"").append(rs1.getString("CONF_VALEFUNC")).append("\"");
            sb.append("},");
            rs1.close(); ps1.close();

            // ── Query 2: total sistema por TIPO_COBRANCA ─────────────────────
            PreparedStatement ps2 = conn.prepareStatement(
                "SELECT mi.TIPO_COBRANCA, SUM(COALESCE(mi.VALOR_INICIAL,0)) AS TOTAL " +
                "FROM FATURAMENTO.FAT_CAIXA c " +
                "JOIN MOVIMENTO.FIN_MOVIMENTO m  ON m.CAIXA_ID  = c.ID " +
                "JOIN MOVIMENTO.FIN_MOVIMENTO_ITEM mi ON mi.MOVIMENTO_ID = m.ID " +
                "WHERE c.SEQUENCEGENERATOR_SEQUENCIA = ? " +
                "  AND m.TIPOMOVIMENTO = 'VENDA' AND m.TIPOSITUACAOMOVIMENTO = 'NORMAL' " +
                "GROUP BY mi.TIPO_COBRANCA ORDER BY mi.TIPO_COBRANCA");
            ps2.setLong(1, caixaNum);
            ResultSet rs2 = ps2.executeQuery();
            sb.append("\"sistema\":{");
            boolean fsist = true;
            while (rs2.next()) {
                if (!fsist) sb.append(","); fsist = false;
                String tc = rs2.getString("TIPO_COBRANCA");
                if (tc == null) tc = "";
                sb.append("\"").append(esc(tc)).append("\":\"")
                  .append(rs2.getString("TOTAL")).append("\"");
            }
            sb.append("}}");
            rs2.close(); ps2.close();

            respJson(ex, 200, sb.toString());
        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage()) + "\"}");
        }
    }

    // ─── FECHAR CAIXA ─────────────────────────────────────────────────────────
    static void serveFecharCaixa(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204,-1); return; }
        if (!"POST".equals(ex.getRequestMethod()))   { ex.sendResponseHeaders(405,-1); return; }

        String body    = new String(readAllBytes(ex.getRequestBody()), StandardCharsets.UTF_8);
        String banco   = extraiJson(body, "banco");
        String caixaId = extraiJson(body, "caixaId");
        if (banco.isEmpty() || caixaId.isEmpty()) {
            respJson(ex, 400, "{\"erro\":\"Parametros invalidos\"}"); return;
        }

        try (Connection conn = conectar(banco)) {
            // Verifica se caixa existe e está aberto
            PreparedStatement psChk = conn.prepareStatement(
                "SELECT c.ID, c.SEQUENCEGENERATOR_SEQUENCIA, c.DATA_ABERTURA, c.DATA_FECHAMENTO, " +
                "COALESCE(c.REPRESENTANTE_ABERTURA_NOME,'') AS OPERADOR, " +
                "COALESCE(c.VALOR_INICIAL,0) AS FUNDO " +
                "FROM FATURAMENTO.FAT_CAIXA c WHERE c.ID = ?");
            psChk.setString(1, caixaId);
            ResultSet rsChk = psChk.executeQuery();
            if (!rsChk.next()) { respJson(ex, 404, "{\"erro\":\"Caixa nao encontrado\"}"); return; }
            if (rsChk.getTimestamp("DATA_FECHAMENTO") != null) {
                respJson(ex, 400, "{\"erro\":\"Caixa ja esta fechado\"}"); return;
            }
            String numero   = rsChk.getString("SEQUENCEGENERATOR_SEQUENCIA");
            String operador = rsChk.getString("OPERADOR");
            Timestamp abertura = rsChk.getTimestamp("DATA_ABERTURA");
            String fundo    = rsChk.getString("FUNDO");
            rsChk.close(); psChk.close();

            // Extrai valores de conferência do body
            double vDinheiro  = extraiDoubleJson(body, "DINHEIRO");
            double vCredito   = extraiDoubleJson(body, "CARTAO_CREDITO");
            double vDebito    = extraiDoubleJson(body, "CARTAO_DEBITO");
            double vPix       = extraiDoubleJson(body, "PIX");
            double vCarteira  = extraiDoubleJson(body, "CARTEIRA_DIGITAL");
            double vCheque    = extraiDoubleJson(body, "CHEQUE");
            double vCredLoja  = extraiDoubleJson(body, "CREDITO_LOJA");
            double vTroca     = extraiDoubleJson(body, "VALE_TROCA");
            double vFuncio    = extraiDoubleJson(body, "VALE_FUNCIONARIO");

            PreparedStatement psUpd = conn.prepareStatement(
                "UPDATE FATURAMENTO.FAT_CAIXA SET " +
                "DATA_FECHAMENTO = CURRENT_TIMESTAMP, " +
                "VALOR_DINHEIRO_CONFERENCIA        = ?, " +
                "VALOR_CARTAOCREDITO_CONFERENCIA   = ?, " +
                "VALOR_CARTAODEBITO_CONFERENCIA    = ?, " +
                "VALOR_PIX_CONFERENCIA             = ?, " +
                "VALOR_CARTEIRADIGITAL_CONFERENCIA = ?, " +
                "VALOR_CHEQUE_CONFERENCIA          = ?, " +
                "VALOR_CREDITOLOJA_CONFERENCIA     = ?, " +
                "VALOR_TROCA_CONFERENCIA           = ?, " +
                "VALOR_VALEFUNCIONARIO_CONFERENCIA = ? " +
                "WHERE ID = ? AND DATA_FECHAMENTO IS NULL");
            psUpd.setDouble(1, vDinheiro);
            psUpd.setDouble(2, vCredito);
            psUpd.setDouble(3, vDebito);
            psUpd.setDouble(4, vPix);
            psUpd.setDouble(5, vCarteira);
            psUpd.setDouble(6, vCheque);
            psUpd.setDouble(7, vCredLoja);
            psUpd.setDouble(8, vTroca);
            psUpd.setDouble(9, vFuncio);
            psUpd.setString(10, caixaId);
            int rows = psUpd.executeUpdate();
            psUpd.close();

            if (rows == 0) { respJson(ex, 400, "{\"erro\":\"Caixa nao foi fechado — verifique se ja estava fechado\"}"); return; }

            // Busca totais do sistema por forma de pagamento para o comprovante
            PreparedStatement psSist = conn.prepareStatement(
                "SELECT mi.TIPO_COBRANCA, SUM(COALESCE(mi.VALOR_INICIAL,0)) AS TOTAL " +
                "FROM MOVIMENTO.FIN_MOVIMENTO m " +
                "JOIN MOVIMENTO.FIN_MOVIMENTO_ITEM mi ON mi.MOVIMENTO_ID = m.ID " +
                "WHERE m.CAIXA_ID = ? AND m.TIPOMOVIMENTO='VENDA' AND m.TIPOSITUACAOMOVIMENTO='NORMAL' " +
                "GROUP BY mi.TIPO_COBRANCA ORDER BY mi.TIPO_COBRANCA");
            psSist.setString(1, caixaId);
            ResultSet rsSist = psSist.executeQuery();
            StringBuilder sistJson = new StringBuilder("{");
            boolean firstS = true;
            while (rsSist.next()) {
                if (!firstS) sistJson.append(","); firstS = false;
                String tc = rsSist.getString("TIPO_COBRANCA");
                if (tc == null) tc = "";
                sistJson.append("\"").append(esc(tc)).append("\":\"")
                        .append(rsSist.getString("TOTAL")).append("\"");
            }
            sistJson.append("}");
            rsSist.close(); psSist.close();

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            respJson(ex, 200,
                "{\"ok\":true," +
                "\"numero\":\"" + esc(numero) + "\"," +
                "\"operador\":\"" + esc(operador) + "\"," +
                "\"abertura\":\"" + (abertura != null ? sdf.format(abertura) : "") + "\"," +
                "\"fundo\":\"" + fundo + "\"," +
                "\"conferencia\":{" +
                "\"DINHEIRO\":" + vDinheiro + "," +
                "\"CARTAO_CREDITO\":" + vCredito + "," +
                "\"CARTAO_DEBITO\":" + vDebito + "," +
                "\"PIX\":" + vPix + "," +
                "\"CARTEIRA_DIGITAL\":" + vCarteira + "," +
                "\"CHEQUE\":" + vCheque + "," +
                "\"CREDITO_LOJA\":" + vCredLoja + "," +
                "\"VALE_TROCA\":" + vTroca + "," +
                "\"VALE_FUNCIONARIO\":" + vFuncio +
                "}," +
                "\"sistema\":" + sistJson + "}");

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage() != null ? e.getMessage() : e.toString()) + "\"}");
        }
    }

    // ─── SINCRONIZAR FECHAMENTO COM RETAGUARDA ────────────────────────────────

    static String jStr(String v) {
        return v == null ? "null" : "\"" + esc(v) + "\"";
    }
    static String jDate(Timestamp ts, SimpleDateFormat f) {
        return ts == null ? "null" : "\"" + f.format(ts) + "\"";
    }

    static String sincFecharCaixaRetaguarda(Connection conn, String caixaId,
            double vDin, double vCred, double vDeb, double vPix,
            double vCart, double vCheq, double vCredL, double vTroca, double vFunc) {
        try {
            // 1. Ler config.properties
            Properties cfg = new Properties();
            File cfgFile = new File(DIR_PDV + "/config.properties");
            if (!cfgFile.exists()) return "config.properties nao encontrado em " + DIR_PDV;
            try (FileInputStream fis = new FileInputStream(cfgFile)) { cfg.load(fis); }

            String serial = cfg.getProperty("serial", "");
            String proto  = cfg.getProperty("sgi_protocolo", "https://");
            String host   = cfg.getProperty("sgi_host", "");
            String port   = cfg.getProperty("sgi_port", "443");
            if (host.isEmpty())   return "sgi_host nao configurado em config.properties";
            if (serial.isEmpty()) return "serial nao configurado em config.properties";

            // Remove escaping de ":" que pode existir no .properties (sgi_protocolo=https\://)
            proto = proto.replace("\\:", ":");
            String rtUrl = proto + host + ":" + port + "/sgi/rest/mobile/fecharCaixa";

            // 2. Buscar PDV por serial em ARARATI.PDV
            String pdvId = null, numeroPDV = null, empresaId = null;
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT ID, NUMERO_CAIXA, EMPRESA_ID FROM ARARATI.PDV " +
                    "WHERE SERIAL = ? FETCH FIRST 1 ROWS ONLY")) {
                ps.setString(1, serial);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    pdvId     = rs.getString(1);
                    numeroPDV = rs.getString(2);
                    empresaId = rs.getString(3);
                }
                rs.close();
            }
            if (pdvId == null) return "PDV com serial " + serial + " nao encontrado no banco " +
                "(tabela ARARATI.PDV)";

            // 3. Buscar dados completos do FAT_CAIXA (ja atualizado)
            String caixaNumSeq = null, repAberPessId = null, repFecPessId = null;
            Timestamp dtAb = null, dtFec = null, dtAtualCaixa = null;
            double valInic = 0;

            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT SEQUENCEGENERATOR_SEQUENCIA, DATA_ABERTURA, DATA_FECHAMENTO, " +
                    "COALESCE(VALOR_INICIAL, 0) AS VALOR_INICIAL, " +
                    "REPRESENTANTE_ABERTURA_PESSOA_ID, REPRESENTANTE_FECHAMENTO_PESSOA_ID, " +
                    "DATAATUALIZACAO " +
                    "FROM FATURAMENTO.FAT_CAIXA WHERE ID = ?")) {
                ps.setString(1, caixaId);
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) return "Caixa nao encontrado pos-update";
                caixaNumSeq   = rs.getString("SEQUENCEGENERATOR_SEQUENCIA");
                dtAb          = rs.getTimestamp("DATA_ABERTURA");
                dtFec         = rs.getTimestamp("DATA_FECHAMENTO");
                valInic       = rs.getDouble("VALOR_INICIAL");
                repAberPessId = rs.getString("REPRESENTANTE_ABERTURA_PESSOA_ID");
                repFecPessId  = rs.getString("REPRESENTANTE_FECHAMENTO_PESSOA_ID");
                dtAtualCaixa  = rs.getTimestamp("DATAATUALIZACAO");
                rs.close();
            }

            // 4. Buscar movimentos do caixa (FIN_MOVIMENTO + FIN_MOVIMENTO_ITEM)
            SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
            StringBuilder sbItens = new StringBuilder("[");
            boolean firstMov = true;
            List<String> movIds = new ArrayList<>();

            try (PreparedStatement psMov = conn.prepareStatement(
                    "SELECT ID, TIPOMOVIMENTO, TIPOSITUACAOMOVIMENTO, DATA_ABERTURA, " +
                    "REPRESENTANTE_ID, EMPRESA_ID, CONTA_ID, CODIGO_PEDIDO, " +
                    "PESSOA_MOVIMENTO_ID, GERA_FINANCEIRO, DATAATUALIZACAO " +
                    "FROM MOVIMENTO.FIN_MOVIMENTO WHERE CAIXA_ID = ? " +
                    "ORDER BY DATA_ABERTURA")) {
                psMov.setString(1, caixaId);
                ResultSet rsMov = psMov.executeQuery();

                while (rsMov.next()) {
                    String movId      = rsMov.getString("ID");
                    String tipoMov    = rsMov.getString("TIPOMOVIMENTO");
                    String tipoSit    = rsMov.getString("TIPOSITUACAOMOVIMENTO");
                    Timestamp emiss   = rsMov.getTimestamp("DATA_ABERTURA");
                    String usuId      = rsMov.getString("REPRESENTANTE_ID");
                    String empMvId    = rsMov.getString("EMPRESA_ID");
                    String contId     = rsMov.getString("CONTA_ID");
                    String codPed     = rsMov.getString("CODIGO_PEDIDO");
                    String pessMvId   = rsMov.getString("PESSOA_MOVIMENTO_ID");
                    boolean geraFin   = rsMov.getBoolean("GERA_FINANCEIRO");
                    Timestamp dtAtMov = rsMov.getTimestamp("DATAATUALIZACAO");
                    boolean cancelado = "CANCELADO".equals(tipoSit);
                    String empFinal   = (empMvId != null && !empMvId.isEmpty()) ? empMvId : empresaId;
                    movIds.add(movId);

                    // 4a. Itens do movimento
                    StringBuilder sbMI = new StringBuilder("[");
                    boolean firstMI = true;

                    try (PreparedStatement psMI = conn.prepareStatement(
                            "SELECT ID, VALOR_INICIAL, TIPO_COBRANCA, CARTAO_CREDITO_ID, " +
                            "CARTEIRA_DIGITAL_ID, DESCRICAO_CARTAO, CREDENCIADORA_PESSOA_ID, " +
                            "CREDENCIADORA_PESSOA_NOMERAZAO, CREDENCIADORA_CODIGO, " +
                            "PRAZO_PARCELAMENTO_SELECIONADO, DATAATUALIZACAO " +
                            "FROM MOVIMENTO.FIN_MOVIMENTO_ITEM WHERE MOVIMENTO_ID = ?")) {
                        psMI.setString(1, movId);
                        ResultSet rsMI = psMI.executeQuery();
                        while (rsMI.next()) {
                            String miId      = rsMI.getString("ID");
                            double miValor   = rsMI.getDouble("VALOR_INICIAL");
                            String tipoCob   = rsMI.getString("TIPO_COBRANCA");
                            String ccId      = rsMI.getString("CARTAO_CREDITO_ID");
                            String cdId      = rsMI.getString("CARTEIRA_DIGITAL_ID");
                            String descCart  = rsMI.getString("DESCRICAO_CARTAO");
                            String credId    = rsMI.getString("CREDENCIADORA_PESSOA_ID");
                            String credNome  = rsMI.getString("CREDENCIADORA_PESSOA_NOMERAZAO");
                            String credCod   = rsMI.getString("CREDENCIADORA_CODIGO");
                            int prazo        = rsMI.getInt("PRAZO_PARCELAMENTO_SELECIONADO");
                            Timestamp dtAtMI = rsMI.getTimestamp("DATAATUALIZACAO");

                            if (!firstMI) sbMI.append(",");
                            firstMI = false;
                            sbMI.append("{")
                                .append("\"id\":").append(jStr(miId)).append(",")
                                .append("\"sinc\":false,")
                                .append("\"dataAtualizacao\":").append(jDate(dtAtMI, iso)).append(",")
                                .append("\"valor\":").append(miValor).append(",")
                                .append("\"valorSupertroco\":null,")
                                .append("\"tipoCobranca\":").append(jStr(tipoCob)).append(",")
                                .append("\"tef\":null,")
                                .append("\"cartaoCreditoId\":").append(jStr(ccId)).append(",")
                                .append("\"carteiraDigitalId\":").append(jStr(cdId)).append(",")
                                .append("\"descricaoCartao\":").append(jStr(descCart)).append(",")
                                .append("\"credenciadoraPessoaId\":").append(jStr(credId)).append(",")
                                .append("\"credenciadoraPessoaNomeRazao\":").append(jStr(credNome)).append(",")
                                .append("\"codigoCredenciadora\":").append(jStr(credCod)).append(",")
                                .append("\"prazosParcelamentoSelecionado\":").append(prazo).append(",")
                                .append("\"supertrocoVenda\":null")
                                .append("}");
                        }
                        rsMI.close();
                    }
                    sbMI.append("]");

                    if (!firstMov) sbItens.append(",");
                    firstMov = false;
                    sbItens.append("{")
                        .append("\"id\":").append(jStr(movId)).append(",")
                        .append("\"sinc\":false,")
                        .append("\"dataAtualizacao\":").append(jDate(dtAtMov, iso)).append(",")
                        .append("\"observacao\":null,")
                        .append("\"tipoMovimento\":").append(jStr(tipoMov)).append(",")
                        .append("\"empresaId\":").append(jStr(empFinal)).append(",")
                        .append("\"usuarioId\":").append(jStr(usuId)).append(",")
                        .append("\"pessoaMovimentoId\":").append(jStr(pessMvId)).append(",")
                        .append("\"emissao\":").append(jDate(emiss, iso)).append(",")
                        .append("\"numeroCaixa\":").append(jStr(numeroPDV)).append(",")
                        .append("\"contaId\":").append(jStr(contId)).append(",")
                        .append("\"cancelado\":").append(cancelado).append(",")
                        .append("\"geraFinanceiro\":").append(geraFin).append(",")
                        .append("\"codigoPedido\":").append(jStr(codPed)).append(",")
                        .append("\"caixaId\":").append(jStr(caixaId)).append(",")
                        .append("\"itens\":").append(sbMI)
                        .append("}");
                }
                rsMov.close();
            }
            sbItens.append("]");

            // 5. Montar JSON do CaixaWS
            String json = "{"
                + "\"id\":"                              + jStr(caixaId)       + ","
                + "\"sinc\":false,"
                + "\"dataAtualizacao\":"                 + jDate(dtAtualCaixa, iso) + ","
                + "\"numeroSequencialCaixa\":"           + jStr(caixaNumSeq)   + ","
                + "\"numeroPDV\":"                       + jStr(numeroPDV)     + ","
                + "\"pdvId\":"                           + jStr(pdvId)         + ","
                + "\"empresaId\":"                       + jStr(empresaId)     + ","
                + "\"dataAbertura\":"                    + jDate(dtAb, iso)    + ","
                + "\"dataFechamento\":"                  + jDate(dtFec, iso)   + ","
                + "\"valorInicial\":"                    + valInic             + ","
                + "\"representanteAberturaPessoaId\":"   + jStr(repAberPessId) + ","
                + "\"representanteFechamentoPessoaId\":" + jStr(repFecPessId)  + ","
                + "\"valorDinheiroConferencia\":"        + vDin                + ","
                + "\"valorCartaoCreditoConferencia\":"   + vCred               + ","
                + "\"valorCartaoDebitoConferencia\":"    + vDeb                + ","
                + "\"valorPixConferencia\":"             + vPix                + ","
                + "\"valorCarteiraDigitalConferencia\":" + vCart               + ","
                + "\"valorChequeConferencia\":"          + vCheq               + ","
                + "\"valorCreditoLojaConferencia\":"     + vCredL              + ","
                + "\"valorValeTrocaConferencia\":"       + vTroca              + ","
                + "\"valorValeFuncionarioConferencia\":" + vFunc               + ","
                + "\"itens\":"                           + sbItens
                + "}";

            // 6. POST para retaguarda via HTTPS (trust-all)
            URL rtUrlObj = new URL(rtUrl);
            HttpsURLConnection hc = (HttpsURLConnection) rtUrlObj.openConnection();
            SSLContext sslCtx = SSLContext.getInstance("TLS");
            sslCtx.init(null, new TrustManager[]{ new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }}, new SecureRandom());
            hc.setSSLSocketFactory(sslCtx.getSocketFactory());
            hc.setHostnameVerifier((h, s) -> true);
            hc.setConnectTimeout(10000);
            hc.setReadTimeout(30000);
            hc.setRequestMethod("POST");
            hc.setDoOutput(true);
            hc.setRequestProperty("Content-Type", "application/json");
            hc.setRequestProperty("Accept", "application/json");
            byte[] bodyBytes = json.getBytes(StandardCharsets.UTF_8);
            hc.setRequestProperty("Content-Length", String.valueOf(bodyBytes.length));
            try (OutputStream ost = hc.getOutputStream()) { ost.write(bodyBytes); }

            int httpCode = hc.getResponseCode();
            InputStream rtIs = httpCode < 400 ? hc.getInputStream() : hc.getErrorStream();
            String rtBody = rtIs != null
                ? new String(readAllBytes(rtIs), StandardCharsets.UTF_8) : "";
            hc.disconnect();

            if (httpCode < 200 || httpCode >= 300) {
                return "Retaguarda HTTP " + httpCode + ": " +
                    rtBody.substring(0, Math.min(300, rtBody.length()));
            }

            // 7. Sucesso: marcar SINC=true
            conn.createStatement().executeUpdate(
                "UPDATE FATURAMENTO.FAT_CAIXA SET SINC = true " +
                "WHERE ID = '" + caixaId.replace("'", "''") + "'");

            if (!movIds.isEmpty()) {
                StringBuilder inMov = new StringBuilder("(");
                for (int i = 0; i < movIds.size(); i++) {
                    if (i > 0) inMov.append(",");
                    inMov.append("'").append(movIds.get(i).replace("'","''")).append("'");
                }
                inMov.append(")");
                String inMovStr = inMov.toString();
                conn.createStatement().executeUpdate(
                    "UPDATE MOVIMENTO.FIN_MOVIMENTO SET SINC = true WHERE ID IN " + inMovStr);
                conn.createStatement().executeUpdate(
                    "UPDATE MOVIMENTO.FIN_MOVIMENTO_ITEM SET SINC = true " +
                    "WHERE MOVIMENTO_ID IN " + inMovStr);
            }

            return ""; // sucesso

        } catch (Exception e) {
            return e.getMessage() != null ? e.getMessage() : e.toString();
        }
    }

    // ─── INFO BANCO (empresa + numero PDV) ───────────────────────────────────
    static void serveInfoBanco(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204,-1); return; }

        Map<String,String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco = p.getOrDefault("banco", "");
        if (banco.isEmpty()) { respJson(ex, 400, "{\"erro\":\"Banco nao informado\"}"); return; }

        try (Connection conn = conectar(banco)) {
            // ── Empresa ──────────────────────────────────────────────────────
            String empresa = "";
            try {
                ResultSet r = conn.createStatement().executeQuery(
                    "SELECT EMIT_XNOME FROM NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                    "WHERE EMIT_XNOME IS NOT NULL FETCH FIRST 1 ROWS ONLY");
                if (r.next()) { String v = r.getString(1); if (v != null) empresa = v.trim(); }
                r.close();
            } catch (Exception ignored) {}

            if (empresa.isEmpty()) {
                String[][] tabs = {
                    {"NFE.EMPRESA","XNOME"}, {"NFE.EMPRESA","NOME"},
                    {"SGI.EMPRESA","XNOME"}, {"NFE.CONFIG_EMPRESA","XNOME"}
                };
                for (String[] t : tabs) {
                    try {
                        ResultSet r = conn.createStatement().executeQuery(
                            "SELECT " + t[1] + " FROM " + t[0] + " FETCH FIRST 1 ROWS ONLY");
                        if (r.next()) { String v = r.getString(1); if (v != null && !v.trim().isEmpty()) empresa = v.trim(); }
                        r.close();
                        if (!empresa.isEmpty()) break;
                    } catch (Exception ignored) {}
                }
            }

            // ── Série (número do PDV) ─────────────────────────────────────────
            String serie = "";
            try {
                ResultSet r = conn.createStatement().executeQuery(
                    "SELECT IDE_SERIE FROM NFE.NFE_NOTA_FISCAL_ELETRONICA " +
                    "GROUP BY IDE_SERIE ORDER BY COUNT(*) DESC FETCH FIRST 1 ROWS ONLY");
                if (r.next()) { String v = r.getString(1); if (v != null) serie = v.trim(); }
                r.close();
            } catch (Exception ignored) {}

            respJson(ex, 200,
                "{\"empresa\":\"" + esc(empresa) + "\"," +
                "\"serie\":\"" + esc(serie) + "\"}");

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage() != null ? e.getMessage() : e.toString()) + "\"}");
        }
    }

    // ─── SINC STATUS ─────────────────────────────────────────────────────────
    static void serveSincStatus(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204,-1); return; }

        Map<String,String> p = parseQuery(ex.getRequestURI().getQuery());
        String banco = p.getOrDefault("banco", "");
        if (banco.isEmpty()) { respJson(ex, 400, "{\"erro\":\"Parametro banco obrigatorio\"}"); return; }

        try (Connection conn = conectar(banco)) {
            long caixas = 0, pedidosNf = -1;

            try {
                ResultSet r1 = conn.createStatement().executeQuery(
                    "SELECT COUNT(*) AS N FROM FATURAMENTO.FAT_CAIXA WHERE SINC IS NOT TRUE");
                if (r1.next()) caixas = r1.getLong(1); r1.close();
            } catch (Exception ignore) {}

            try {
                ResultSet r4 = conn.createStatement().executeQuery(
                    "SELECT COUNT(*) AS N FROM FATURAMENTO.FAT_PEDIDO_VENDA " +
                    "WHERE (SINC IS NULL OR SINC = 0) AND NOTA_FISCAL_ELETRONICA_ID IS NOT NULL");
                if (r4.next()) pedidosNf = r4.getLong(1); r4.close();
            } catch (Exception ignore) {}

            respJson(ex, 200, "{\"caixas\":" + caixas + ",\"pedidosNf\":" + pedidosNf + "}");
        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage() != null ? e.getMessage() : e.toString()) + "\"}");
        }
    }

    // ─── RESINC CAIXA ────────────────────────────────────────────────────────
    static void serveResincCaixa(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204,-1); return; }
        if (!"POST".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(405,-1); return; }

        String body    = new String(readAllBytes(ex.getRequestBody()), StandardCharsets.UTF_8);
        String banco   = extraiJson(body, "banco");
        String caixaId = extraiJson(body, "caixaId");
        if (banco.isEmpty() || caixaId.isEmpty()) {
            respJson(ex, 400, "{\"erro\":\"Parametros banco e caixaId obrigatorios\"}"); return;
        }

        try (Connection conn = conectar(banco)) {
            // Busca valores de conferência salvos no banco
            PreparedStatement ps = conn.prepareStatement(
                "SELECT COALESCE(VALOR_DINHEIRO_CONFERENCIA,0) AS DIN," +
                "COALESCE(VALOR_CARTAOCREDITO_CONFERENCIA,0) AS CRED," +
                "COALESCE(VALOR_CARTAODEBITO_CONFERENCIA,0) AS DEB," +
                "COALESCE(VALOR_PIX_CONFERENCIA,0) AS PIX," +
                "COALESCE(VALOR_CARTEIRADIGITAL_CONFERENCIA,0) AS CART," +
                "COALESCE(VALOR_CHEQUE_CONFERENCIA,0) AS CHEQ," +
                "COALESCE(VALOR_CREDITOLOJA_CONFERENCIA,0) AS CREDL," +
                "COALESCE(VALOR_TROCA_CONFERENCIA,0) AS TROCA," +
                "COALESCE(VALOR_VALEFUNCIONARIO_CONFERENCIA,0) AS FUNC," +
                "DATA_FECHAMENTO " +
                "FROM FATURAMENTO.FAT_CAIXA WHERE ID = ?");
            ps.setString(1, caixaId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) { respJson(ex, 404, "{\"erro\":\"Caixa nao encontrado\"}"); return; }
            if (rs.getTimestamp("DATA_FECHAMENTO") == null) {
                respJson(ex, 400, "{\"erro\":\"Caixa ainda esta aberto — feche antes de sincronizar\"}"); return;
            }
            double vDin   = rs.getDouble("DIN");
            double vCred  = rs.getDouble("CRED");
            double vDeb   = rs.getDouble("DEB");
            double vPix   = rs.getDouble("PIX");
            double vCart  = rs.getDouble("CART");
            double vCheq  = rs.getDouble("CHEQ");
            double vCredL = rs.getDouble("CREDL");
            double vTroca = rs.getDouble("TROCA");
            double vFunc  = rs.getDouble("FUNC");
            rs.close(); ps.close();

            String erro = sincFecharCaixaRetaguarda(conn, caixaId,
                vDin, vCred, vDeb, vPix, vCart, vCheq, vCredL, vTroca, vFunc);
            if (erro.isEmpty()) {
                respJson(ex, 200, "{\"ok\":true}");
            } else {
                respJson(ex, 200, "{\"ok\":false,\"erro\":\"" + esc(erro) + "\"}");
            }
        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage() != null ? e.getMessage() : e.toString()) + "\"}");
        }
    }

    // ─── RESINC TODAS AS NF PENDENTES ───────────────────────────────────────────
    static void serveResincNFes(HttpExchange ex) throws IOException {
        addCors(ex);
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204,-1); return; }
        if (!"POST".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(405,-1); return; }

        String body  = new String(readAllBytes(ex.getRequestBody()), StandardCharsets.UTF_8);
        String banco = extraiJson(body, "banco");
        if (banco.isEmpty()) { respJson(ex, 400, "{\"erro\":\"Banco nao informado\"}"); return; }

        try (Connection conn = conectar(banco)) {
            // Ler config
            Properties cfg = new Properties();
            File cfgFile = new File(DIR_PDV + "/config.properties");
            if (!cfgFile.exists()) { respJson(ex, 500, "{\"erro\":\"config.properties nao encontrado em " + DIR_PDV + "\"}"); return; }
            try (FileInputStream fis = new FileInputStream(cfgFile)) { cfg.load(fis); }

            String serial = cfg.getProperty("serial", "");
            String proto  = cfg.getProperty("sgi_protocolo", "https://").replace("\\:", ":");
            String host   = cfg.getProperty("sgi_host", "");
            String port   = cfg.getProperty("sgi_port", "443");
            if (host.isEmpty() || serial.isEmpty()) {
                respJson(ex, 500, "{\"erro\":\"Configuracao incompleta (sgi_host ou serial)\"}"); return;
            }
            String rtUrl = proto + host + ":" + port + "/sgi/rest/mobile/saveNFCeContingencia";

            // Busca empresaId pelo serial
            String empresaId = null;
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT EMPRESA_ID FROM ARARATI.PDV WHERE SERIAL = ? FETCH FIRST 1 ROWS ONLY")) {
                ps.setString(1, serial);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) empresaId = rs.getString(1);
                rs.close();
            }
            if (empresaId == null) {
                respJson(ex, 500, "{\"erro\":\"PDV serial=" + esc(serial) + " nao encontrado em ARARATI.PDV\"}"); return;
            }

            // Busca NF pendentes de sync (pedido com SINC=false e tem NF vinculada)
            List<String> nfeIds = new ArrayList<>();
            try (ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT p.NOTA_FISCAL_ELETRONICA_ID " +
                    "FROM FATURAMENTO.FAT_PEDIDO_VENDA p " +
                    "JOIN NFE.NFE_NOTA_FISCAL_ELETRONICA n ON n.ID = p.NOTA_FISCAL_ELETRONICA_ID " +
                    "WHERE (p.SINC IS NULL OR p.SINC = 0) " +
                    "  AND p.NOTA_FISCAL_ELETRONICA_ID IS NOT NULL " +
                    "  AND n.TIPO_SITUACAO = 'AUTORIZADO'")) {
                while (rs.next()) nfeIds.add(rs.getString(1));
            } catch (Exception e1) {
                // fallback sem filtro de TIPO_SITUACAO
                try (ResultSet rs = conn.createStatement().executeQuery(
                        "SELECT NOTA_FISCAL_ELETRONICA_ID FROM FATURAMENTO.FAT_PEDIDO_VENDA " +
                        "WHERE (SINC IS NULL OR SINC = 0) AND NOTA_FISCAL_ELETRONICA_ID IS NOT NULL")) {
                    while (rs.next()) nfeIds.add(rs.getString(1));
                } catch (Exception e2) {
                    respJson(ex, 500, "{\"erro\":\"Erro ao buscar NF pendentes: " + esc(e2.getMessage()) + "\"}"); return;
                }
            }

            // Sincroniza cada NF
            int ok = 0;
            List<String> erros = new ArrayList<>();
            SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

            for (String nfeId : nfeIds) {
                String err = sincNFeRetaguarda(conn, nfeId, empresaId, rtUrl, iso);
                if (err.isEmpty()) ok++;
                else erros.add("{\"nfeId\":\"" + esc(nfeId) + "\",\"erro\":\"" + esc(err) + "\"}");
            }

            StringBuilder result = new StringBuilder("{");
            result.append("\"total\":").append(nfeIds.size()).append(",");
            result.append("\"sincronizados\":").append(ok).append(",");
            result.append("\"erros\":[");
            for (int i = 0; i < erros.size(); i++) { if (i > 0) result.append(","); result.append(erros.get(i)); }
            result.append("]}");
            respJson(ex, 200, result.toString());

        } catch (Exception e) {
            respJson(ex, 500, "{\"erro\":\"" + esc(e.getMessage() != null ? e.getMessage() : e.toString()) + "\"}");
        }
    }

    static String sincNFeRetaguarda(Connection conn, String nfeId, String empresaId, String rtUrl, SimpleDateFormat iso) {
        try {
            // Busca campos da NF
            String chave = null, serie = null, mod = null, nnf = null, cuf = null, tpAmb = null;
            String tipoSit = null, protocolo = null, emitCnpj = null, emitNome = null, emitEnderUF = null;
            String destCnpj = null, destNome = null;
            java.math.BigDecimal vnf = null;
            Timestamp dhemi = null, dataAuth = null;
            boolean emitidaContingencia = false;

            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT ID, IDE_NNF, IDE_SERIE, IDE_MOD, IDE_CUF, IDE_TPAMB, " +
                    "IDE_DHEMI, DATA_HORA_AUTORIZACAO, CHAVE_ACESSO, VNF, " +
                    "PROTOCOLOAUTORIZACAO, EMITIDA_CONTINGENCIA, TIPO_SITUACAO, " +
                    "EMIT_CNPJ, EMIT_XNOME, EMIT_ENDERUF, DEST_CNPJ, DEST_XNOME " +
                    "FROM NFE.NFE_NOTA_FISCAL_ELETRONICA WHERE ID = ?")) {
                ps.setString(1, nfeId);
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) return "NF nao encontrada: " + nfeId;
                chave  = rs.getString("CHAVE_ACESSO");
                serie  = rs.getString("IDE_SERIE");
                mod    = rs.getString("IDE_MOD");
                nnf    = rs.getString("IDE_NNF");
                cuf    = rs.getString("IDE_CUF");
                tpAmb  = rs.getString("IDE_TPAMB");
                dhemi  = rs.getTimestamp("IDE_DHEMI");
                dataAuth  = rs.getTimestamp("DATA_HORA_AUTORIZACAO");
                tipoSit   = rs.getString("TIPO_SITUACAO");
                protocolo = rs.getString("PROTOCOLOAUTORIZACAO");
                emitidaContingencia = rs.getBoolean("EMITIDA_CONTINGENCIA");
                emitCnpj    = rs.getString("EMIT_CNPJ");
                emitNome    = rs.getString("EMIT_XNOME");
                emitEnderUF = rs.getString("EMIT_ENDERUF");
                destCnpj    = rs.getString("DEST_CNPJ");
                destNome    = rs.getString("DEST_XNOME");
                vnf = rs.getBigDecimal("VNF");
                rs.close();
            }

            // Busca ID do pedido vinculado
            String pedidoId = null;
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT ID FROM FATURAMENTO.FAT_PEDIDO_VENDA " +
                    "WHERE NOTA_FISCAL_ELETRONICA_ID = ? FETCH FIRST 1 ROWS ONLY")) {
                ps.setString(1, nfeId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) pedidoId = rs.getString(1);
                rs.close();
            } catch (Exception ignored) {}

            // Busca XMLs de distribuição (autorização, cancelamento, etc.)
            StringBuilder sbDist = new StringBuilder("[");
            boolean firstDist = true;
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT CHAVE_ACESSO, TIPO_DISTRIBUICAO, NPROT, NSEQEVENTO, DHRECEBTO, XML_ARQUIVO " +
                    "FROM NFE.NFE_DISTRIBUICAO_XML WHERE NOTA_FISCAL_ELETRONICA_ID = ?")) {
                ps.setString(1, nfeId);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    if (!firstDist) sbDist.append(",");
                    firstDist = false;
                    String chaveD  = rs.getString("CHAVE_ACESSO");
                    String tipoDist = rs.getString("TIPO_DISTRIBUICAO");
                    String nprot   = rs.getString("NPROT");
                    String nseq    = rs.getString("NSEQEVENTO");
                    String dhreceb = rs.getString("DHRECEBTO");
                    Blob   blob    = rs.getBlob("XML_ARQUIVO");
                    String xmlB64  = null;
                    if (blob != null) {
                        byte[] bytes = blob.getBytes(1, (int) blob.length());
                        xmlB64 = java.util.Base64.getEncoder().encodeToString(bytes);
                        blob.free();
                    }
                    sbDist.append("{")
                        .append("\"chnfe\":").append(jStr(chaveD)).append(",")
                        .append("\"tpEvento\":null,")
                        .append("\"nseqEvento\":").append(jStr(nseq)).append(",")
                        .append("\"nprot\":").append(jStr(nprot)).append(",")
                        .append("\"dhrecebto\":").append(jStr(dhreceb)).append(",")
                        .append("\"nFeTipoDistribuicao\":").append(jStr(tipoDist)).append(",")
                        .append("\"xml\":").append(xmlB64 != null ? "\"" + xmlB64 + "\"" : "null")
                        .append("}");
                }
                rs.close();
            } catch (Exception ignored) {}
            sbDist.append("]");

            // Monta JSON NotaFiscalEletronicaWS
            String json = "{"
                + "\"id\":\"" + esc(nfeId) + "\","
                + "\"chnfe\":" + jStr(chave) + ","
                + "\"ideserie\":" + jStr(serie) + ","
                + "\"idemod\":" + jStr(mod) + ","
                + "\"idenNF\":" + jStr(nnf) + ","
                + "\"idecUF\":" + jStr(cuf) + ","
                + "\"idetpAmb\":" + jStr(tpAmb) + ","
                + "\"idedhemi\":" + jDate(dhemi, iso) + ","
                + "\"dataHoraAutorizacao\":" + jDate(dataAuth, iso) + ","
                + "\"situacao\":" + jStr(tipoSit) + ","
                + "\"protocoloAutorizacao\":" + jStr(protocolo) + ","
                + "\"emitidaContingencia\":" + emitidaContingencia + ","
                + "\"emitCNPJ\":" + jStr(emitCnpj) + ","
                + "\"emitxNome\":" + jStr(emitNome) + ","
                + "\"emitEnderUF\":" + jStr(emitEnderUF) + ","
                + "\"destCNPJ\":" + jStr(destCnpj) + ","
                + "\"destxNome\":" + jStr(destNome) + ","
                + "\"vnf\":" + (vnf != null ? vnf.toPlainString() : "0") + ","
                + "\"empresaId\":" + jStr(empresaId) + ","
                + "\"pedidoVendaId\":" + jStr(pedidoId) + ","
                + "\"distribuicaoXmls\":" + sbDist + ","
                + "\"produtosServicos\":[],"
                + "\"retEventoXmls\":[],"
                + "\"dadosCobrancas\":[],"
                + "\"pagamento\":null"
                + "}";

            // POST para retaguarda (trust-all SSL, igual fecharCaixa)
            URL rtUrlObj = new URL(rtUrl);
            HttpsURLConnection hc = (HttpsURLConnection) rtUrlObj.openConnection();
            SSLContext sslCtx = SSLContext.getInstance("TLS");
            sslCtx.init(null, new TrustManager[]{ new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }}, new SecureRandom());
            hc.setSSLSocketFactory(sslCtx.getSocketFactory());
            hc.setHostnameVerifier((h, s) -> true);
            hc.setConnectTimeout(10000);
            hc.setReadTimeout(30000);
            hc.setRequestMethod("POST");
            hc.setDoOutput(true);
            hc.setRequestProperty("Content-Type", "application/json");
            hc.setRequestProperty("Accept", "application/json");
            hc.setRequestProperty("empresaId", empresaId);
            byte[] bodyBytes = json.getBytes(StandardCharsets.UTF_8);
            hc.setRequestProperty("Content-Length", String.valueOf(bodyBytes.length));
            try (OutputStream ost = hc.getOutputStream()) { ost.write(bodyBytes); }

            int httpCode = hc.getResponseCode();
            InputStream rtIs = httpCode < 400 ? hc.getInputStream() : hc.getErrorStream();
            String rtBody = rtIs != null ? new String(readAllBytes(rtIs), StandardCharsets.UTF_8) : "";
            hc.disconnect();

            if (httpCode < 200 || httpCode >= 300) {
                return "Retaguarda HTTP " + httpCode + ": " + rtBody.substring(0, Math.min(250, rtBody.length()));
            }

            // Sucesso: marcar pedido como SINC=true
            try {
                conn.createStatement().executeUpdate(
                    "UPDATE FATURAMENTO.FAT_PEDIDO_VENDA SET SINC = true " +
                    "WHERE NOTA_FISCAL_ELETRONICA_ID = '" + nfeId.replace("'","''") + "'");
            } catch (Exception ignored) {}

            return "";

        } catch (Exception e) {
            return e.getMessage() != null ? e.getMessage() : e.toString();
        }
    }

    // ─── HELPERS GERAIS ───────────────────────────────────────────────────────

    static List<String> listarBancos() {
        List<String> lista = new ArrayList<>();
        File dir = new File(DIR_PDV);
        if (!dir.exists() || !dir.isDirectory()) return lista;
        File[] filhos = dir.listFiles();
        if (filhos == null) return lista;
        for (File f : filhos) {
            if (f.isDirectory() && f.getName().toLowerCase().startsWith("sgidb")) {
                if (new File(f, "service.properties").exists() || new File(f, "seg0").exists()) {
                    lista.add(f.getName());
                }
            }
        }
        lista.sort((a, b) -> {
            if ("sgidb".equals(a)) return -1;
            if ("sgidb".equals(b)) return 1;
            return b.compareTo(a);
        });
        return lista;
    }

    static Connection conectar(String banco) throws Exception {
        String url = "jdbc:derby:" + DIR_PDV + "/" + banco +
                     ";user=ararati;password=@#8df5ararati@#8";
        return DriverManager.getConnection(url);
    }

    static byte[] xmlDistribuicao(Connection conn, String nfeId, String tipo) throws Exception {
        String sql = "SELECT XML_ARQUIVO FROM NFE.NFE_DISTRIBUICAO_XML " +
                     "WHERE NOTA_FISCAL_ELETRONICA_ID = ? AND TIPO_DISTRIBUICAO = ? FETCH FIRST 1 ROWS ONLY";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nfeId);
            ps.setString(2, tipo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Blob b = rs.getBlob("XML_ARQUIVO");
                return b != null ? b.getBytes(1, (int) b.length()) : null;
            }
        }
        return null;
    }

    static byte[] xmlAssinado(Connection conn, String nfeId) throws Exception {
        String sql = "SELECT XML_ARQUIVO FROM NFE.NFE_ASSINADO_XML " +
                     "WHERE NOTA_FISCAL_ELETRONICA_ID = ? FETCH FIRST 1 ROWS ONLY";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nfeId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Blob b = rs.getBlob("XML_ARQUIVO");
                return b != null ? b.getBytes(1, (int) b.length()) : null;
            }
        }
        return null;
    }

    static String numeroNota(Connection conn, String nfeId) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT IDE_NNF FROM NFE.NFE_NOTA_FISCAL_ELETRONICA WHERE ID = ?")) {
            ps.setString(1, nfeId);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? rs.getString(1) : "desconhecido";
        }
    }

    static String fmtTs(Timestamp ts) {
        if (ts == null) return "";
        return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(ts);
    }

    static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    static String xmlEsc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("'", "&apos;").replace("\"", "&quot;");
    }

    static String tratarErro(Exception e) {
        String msg = e.getMessage() != null ? e.getMessage() : "Erro desconhecido";
        if (msg.contains("XSDB6") || msg.contains("lock") || msg.contains("another instance"))
            return "Banco bloqueado — feche o PDV e tente novamente";
        return msg;
    }

    static void respJson(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(code, bytes.length);
        ex.getResponseBody().write(bytes);
        ex.getResponseBody().close();
    }

    static void respText(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
        ex.sendResponseHeaders(code, bytes.length);
        ex.getResponseBody().write(bytes);
        ex.getResponseBody().close();
    }

    static void addCors(HttpExchange ex) {
        ex.getResponseHeaders().set("Access-Control-Allow-Origin",  "*");
        ex.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
    }

    static Map<String, String> parseQuery(String query) {
        Map<String, String> map = new LinkedHashMap<>();
        if (query == null || query.isEmpty()) return map;
        for (String par : query.split("&")) {
            String[] kv = par.split("=", 2);
            try {
                String k = URLDecoder.decode(kv[0], "UTF-8");
                String v = kv.length > 1 ? URLDecoder.decode(kv[1], "UTF-8") : "";
                map.put(k, v);
            } catch (Exception ignored) {}
        }
        return map;
    }

    static String extraiJson(String json, String key) {
        String s = "\"" + key + "\":\"";
        int i = json.indexOf(s);
        if (i < 0) return "";
        i += s.length();
        int j = json.indexOf("\"", i);
        return j < 0 ? "" : json.substring(i, j);
    }

    static List<String> extraiArray(String json, String key) {
        List<String> list = new ArrayList<>();
        String s = "\"" + key + "\":[";
        int i = json.indexOf(s);
        if (i < 0) return list;
        i += s.length();
        int j = json.indexOf("]", i);
        if (j < 0) return list;
        for (String item : json.substring(i, j).split(",")) {
            String v = item.trim().replaceAll("^\"|\"$", "");
            if (!v.isEmpty()) list.add(v);
        }
        return list;
    }
}
